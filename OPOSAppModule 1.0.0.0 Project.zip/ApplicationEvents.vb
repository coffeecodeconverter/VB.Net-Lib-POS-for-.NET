﻿

Imports System.Runtime.InteropServices
Imports System.Diagnostics


Module NativeMethods
    <DllImport("user32.dll")>
    Public Function SetForegroundWindow(hWnd As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll")>
    Public Function ShowWindow(hWnd As IntPtr, nCmdShow As Integer) As Boolean
    End Function

    Public Const SW_RESTORE As Integer = 9
End Module



Namespace My
    ' The following events are available for MyApplication:
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.
    Partial Friend Class MyApplication

        'Private Sub MyApplication_StartupNextInstance(sender As Object, e As Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs) Handles Me.StartupNextInstance
        '    ' This runs when a second instance is launched
        '    MessageBox.Show("The application is already running.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)

        '    ' Optional: bring the existing window to front
        '    If My.Application.OpenForms.Count > 0 Then
        '        Dim mainForm As Form = My.Application.OpenForms(0)
        '        mainForm.Show()
        '        mainForm.WindowState = FormWindowState.Normal
        '        mainForm.BringToFront()
        '        mainForm.Activate()
        '    End If
        'End Sub


        Private Sub MyApplication_StartupNextInstance(sender As Object, e As Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs) Handles Me.StartupNextInstance

            ' Get the working area of the primary screen
            Dim screenBounds As Rectangle = Screen.PrimaryScreen.WorkingArea

            ' Calculate the point near the bottom-right
            Dim trayPoint As New Point(
                screenBounds.Right - 20 - FormMain.ContextMenuStrip_SystemTray_MainApp.Width, ' 20px from right
                screenBounds.Bottom - 50 - FormMain.ContextMenuStrip_SystemTray_MainApp.Height ' 50px from bottom
            )

            ' Try to get the main form
            If My.Application.OpenForms.Count > 0 Then
                Dim mainForm As Form = My.Application.OpenForms(0)

                'mainForm.Show()
                'If mainForm.WindowState = FormWindowState.Minimized Then
                '    mainForm.WindowState = FormWindowState.Normal
                'End If
                'mainForm.BringToFront()
                'mainForm.Activate()

                MessageBox.Show(mainForm, thisApp_Name & " is already running." & vbCrLf & "Check the System Tray icons", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                FormMain.ContextMenuStrip_SystemTray_MainApp.Show(trayPoint)
            Else
                ' No form exists (probably hidden start)
                ' Find the running process
                Dim currentProcess As Process = Process.GetCurrentProcess()
                Dim processes = Process.GetProcessesByName(currentProcess.ProcessName)

                ' Find the first other process instance
                Dim otherProcess = processes.FirstOrDefault(Function(p) p.Id <> currentProcess.Id)

                If otherProcess IsNot Nothing AndAlso otherProcess.MainWindowHandle <> IntPtr.Zero Then
                    ' Restore and bring to front
                    ShowWindow(otherProcess.MainWindowHandle, SW_RESTORE)
                    SetForegroundWindow(otherProcess.MainWindowHandle)
                End If

                ' Show the message box without an owner (will now be on top)
                MessageBox.Show(thisApp_Name & " is already running." & vbCrLf & "Check the System Tray icons", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                FormMain.ContextMenuStrip_SystemTray_MainApp.Show(trayPoint)
            End If
        End Sub

    End Class
End Namespace
