﻿

Imports System.Security.Policy
Imports System.Text
Imports Microsoft.PointOfService
Imports Microsoft.SqlServer


Public Class OposManager
    Implements IDisposable

    Public Event OnLog(message As String)
    Public Event OnStateChanged()

    Public Event OnMsrDataReceived(t1 As String, t2 As String, t3 As String, t4 As String)
    Public Event OnMsrConfigChanged(isArmed As Boolean)
    Public Event OnMsrSentinelsChanged(enabled As Boolean)
    Public Event OnDrawerStatus(isOpen As Boolean)

    Private explorer As PosExplorer

    Private _activeDevices As New Dictionary(Of String, PosCommon)

    Public Structure DeviceStateInfo
        Public IsOpen As Boolean
        Public IsClaimed As Boolean
        Public IsEnabled As Boolean
        Public ControlState As ControlState
        Public Summary As String
    End Structure


    Public Property MyDrawer As CashDrawer
    Public Property MyMSR As Msr
    Public Property MsrIncludeSentinels As Boolean = False
    Public Property KeepMsrArmed As Boolean = True
    Public Property MyKeylock As Keylock


    Public Enum OPOSStateCheck
        IsOpen
        IsClaimed
        IsEnabled
    End Enum


    Public Sub New()
        explorer = New PosExplorer()
    End Sub



    'Public Function GetActiveDevice(deviceType As String) As PosCommon
    '    Debug.WriteLine("Func GetActiveDevice() - received deviceType: " & deviceType)
    '    Debug.WriteLine("Active device keys:")
    '    For Each key As String In _activeDevices.Keys
    '        Debug.WriteLine(" - " & key)
    '    Next

    '    If _activeDevices.ContainsKey(deviceType) Then
    '        Return _activeDevices(deviceType)
    '    End If
    '    Return Nothing
    'End Function

    ' DEBUG VERSION
    Public Function GetActiveDevice(deviceType As String, Optional caller As String = "Unknown") As PosCommon

        If thisApp_DevDebugMode = True Then
            Debug.WriteLine("")
            Debug.WriteLine($"===== DEBUG START [Caller: {caller}] =====")
            Debug.WriteLine("Func GetActiveDevice() - received deviceType: " & deviceType)

            If _activeDevices Is Nothing OrElse _activeDevices.Count = 0 Then
                Debug.WriteLine("'ActiveDevices' are EMPTY or NULL")
            Else
                Debug.WriteLine("Active device keys:")
                For Each key As String In _activeDevices.Keys
                    Debug.WriteLine("   - Comparing 'KEY' with 'DEVICETYPE': [" & key & "] vs [" & deviceType & "] = Match? " & key.Equals(deviceType))
                Next
            End If
        End If


        If _activeDevices.ContainsKey(deviceType) Then
            If thisApp_DevDebugMode = True Then
                Debug.WriteLine("     MATCH FOUND ✔ for: [" & deviceType & "]")
                Debug.WriteLine("RETURNING DEVICE: " & _activeDevices(deviceType).GetType().Name)
                Debug.WriteLine("_activeDevices(deviceType): " & _activeDevices(deviceType).ToString)
                Debug.WriteLine("===== DEBUG END =====")
                Debug.WriteLine("")
            End If
            Return _activeDevices(deviceType)

        Else
            If thisApp_DevDebugMode = True Then
                Debug.WriteLine("     NO MATCH ✖ for: [" & deviceType & "]")
                Debug.WriteLine("===== DEBUG END =====")
                Debug.WriteLine("")
            End If
            Return Nothing
        End If
    End Function


    Public Function populateDeviceListByType(type As String) As ArrayList
        Dim devices As DeviceCollection = explorer.GetDevices(type)
        Dim list As New ArrayList()
        For Each device As DeviceInfo In devices
            list.Add(device)
        Next
        Return list
    End Function




    Public Function GetDeviceState(deviceCategory As String) As DeviceStateInfo
        Dim state As New DeviceStateInfo()
        Dim dev = GetActiveDevice(deviceCategory, "GetDeviceState")

        If dev Is Nothing Then
            state.IsOpen = False
            state.IsClaimed = False
            state.IsEnabled = False
            state.ControlState = ControlState.Closed
            state.Summary = "Closed"
            Return state
        End If

        ' Fill the structure from the actual device
        state.IsOpen = (dev.State <> ControlState.Closed)
        state.IsClaimed = dev.Claimed
        state.IsEnabled = dev.DeviceEnabled
        state.ControlState = dev.State

        ' Create a human-readable summary
        If Not state.IsOpen Then
            state.Summary = "Closed"
        ElseIf state.IsEnabled Then
            state.Summary = "Enabled"
        ElseIf state.IsClaimed Then
            state.Summary = "Claimed"
        Else
            state.Summary = "Open"
        End If

        Return state
    End Function





    Public Sub OpenDevice(info As DeviceInfo)
        Try
            Dim category As String = info.Type

            ' If a device of this type is already open, close it first
            If _activeDevices.ContainsKey(category) Then
                'VB.Log($"ActiveDevices dictionary found existing key for: '{category}' - closing '{category}' first", LogLevel.Debug)
                CloseDeviceByType(category)
                'VB.Log($"Existing device: '{category}' closed successfully", LogLevel.Debug)
            Else
                'VB.Log($"ActiveDevices dictionary does not contain a key for: '{category}' - on devices to close - proceeding...", LogLevel.Debug)
            End If

            Dim instance = explorer.CreateInstance(info)
            Dim newDevice = DirectCast(instance, PosCommon)

            ' Add specific event handlers based on type
            If TypeOf newDevice Is CashDrawer Then
                MyDrawer = DirectCast(newDevice, CashDrawer)
                AddHandler MyDrawer.StatusUpdateEvent, AddressOf Drawer_StatusUpdate
            ElseIf TypeOf newDevice Is Msr Then
                MyMSR = DirectCast(newDevice, Msr)
                AddHandler MyMSR.DataEvent, AddressOf MyMSR_DataEvent
                AddHandler MyMSR.ErrorEvent, AddressOf MSR_ErrorEvent
            End If

            newDevice.Open()

            ' Store it in our dictionary
            _activeDevices(category) = newDevice

            RaiseEvent OnLog($"OPOS COMMAND: {category} Opened: {info.ServiceObjectName}")
            VB.Log($"OPOS COMMAND: {category} Opened: {info.ServiceObjectName}", LogLevel.Debug)

            RaiseEvent OnStateChanged()
        Catch ex As Exception
            RaiseEvent OnLog("OPOS COMMAND ERROR: " & ex.Message)
            VB.Log("OPOS COMMAND ERROR: ", LogLevel.Trace, ex)
        End Try
    End Sub




    'Public Sub OpenDeviceByLogicalName(logicalName As String, type As String)
    '    Try
    '        ' Cleanup old device if exists
    '        If ActiveDevice IsNot Nothing Then
    '            CloseActiveDevice()
    '        End If

    '        ' 1. Find the device by its Logical Name (LDN)
    '        Dim devices As DeviceCollection = explorer.GetDevices(type)
    '        Dim selectedDevice As DeviceInfo = Nothing

    '        ' Search for the LDN in the logical names collection
    '        For Each info As DeviceInfo In devices
    '            For Each lName In info.LogicalNames
    '                If lName.Equals(logicalName, StringComparison.OrdinalIgnoreCase) Then
    '                    selectedDevice = info
    '                    Exit For
    '                End If
    '            Next
    '            If selectedDevice IsNot Nothing Then Exit For
    '        Next

    '        ' 2. Fallback: If not found in logical names, try matching the Service Object Name
    '        If selectedDevice Is Nothing Then
    '            selectedDevice = explorer.GetDevice(type, logicalName)
    '        End If

    '        If selectedDevice Is Nothing Then
    '            RaiseEvent OnLog($"OPOS OPEN ERROR: Logical Device Name (LDN) '{logicalName}' not found.")
    '            Return
    '        End If

    '        ' 3. Standard Initialization
    '        Dim instance = explorer.CreateInstance(selectedDevice)
    '        ActiveDevice = DirectCast(instance, PosCommon)

    '        If TypeOf ActiveDevice Is CashDrawer Then
    '            MyDrawer = DirectCast(ActiveDevice, CashDrawer)
    '            AddHandler MyDrawer.StatusUpdateEvent, AddressOf Drawer_StatusUpdate
    '        End If

    '        ActiveDevice.Open()
    '        RaiseEvent OnLog($"OPOS OPEN: Device Opened via Logical Device Name (LDN): {logicalName}")
    '        RaiseEvent OnStateChanged()

    '    Catch ex As Exception
    '        RaiseEvent OnLog("OPOS OPEN: Logical Device Name (LDN) Error: " & ex.Message)
    '    End Try
    'End Sub



    Public Sub OpenDeviceByLogicalName(logicalName As String, type As String)
        Try
            ' --- ADD THIS NORMALIZATION BLOCK ---
            'Dim normalizedType As String = type.Trim()
            'Select Case normalizedType.ToLowerInvariant()
            '    Case "cash_drawer", "cashdrawer"
            '        normalizedType = "CashDrawer"
            '        FormMain.TabControl_Main.SelectedTab = FormMain.TabPage_Main_CashDrawer

            '    Case "msr"
            '        normalizedType = "Msr"
            '        FormMain.TabControl_Main.SelectedTab = FormMain.TabPage_Main_MSR
            'End Select


            ' Cleanup old device
            If _activeDevices.ContainsKey(type) Then
                'VB.Log($"ActiveDevices dictionary found existing key for: '{type}' - closing '{type}' first", LogLevel.Debug)
                CloseDeviceByType(type)
                'VB.Log($"Existing device: '{type}' closed successfully", LogLevel.Debug)
            Else
                'VB.Log($"ActiveDevices dictionary does not contain a key for: '{type}' - on devices to close - proceeding...", LogLevel.Debug)
            End If


            ' Find the device by its Logical Name (LDN)
            Dim devices As DeviceCollection = explorer.GetDevices(type)
            Dim selectedDevice As DeviceInfo = Nothing

            ' Search for the LDN in the logical names collection
            For Each info As DeviceInfo In devices
                For Each lName In info.LogicalNames
                    If lName.Equals(logicalName, StringComparison.OrdinalIgnoreCase) Then
                        selectedDevice = info
                        Exit For
                    End If
                Next
                If selectedDevice IsNot Nothing Then
                    Exit For
                End If
            Next

            ' Fallback: If not found in logical names, try matching the Service Object Name
            If selectedDevice Is Nothing Then
                Try
                    selectedDevice = explorer.GetDevice(type, logicalName)
                Catch
                    ' GetDevice throws an exception if not found, we handle it below
                End Try
            End If

            ' Verify we actually found something
            If selectedDevice Is Nothing Then
                RaiseEvent OnLog($"OPOS COMMAND ERROR: Logical Device Name (LDN) '{logicalName}' not found for type {type}.")
                VB.Log($"OPOS COMMAND ERROR: Logical Device Name (LDN) '{logicalName}' not found for type {type}.", LogLevel.Debug)
                Return
            End If

            ' 4. Create and Initialize the Instance
            Dim instance = explorer.CreateInstance(selectedDevice)
            Dim newDevice = DirectCast(instance, PosCommon)

            ' 5. Setup Type-Specific Handlers and Shortcuts
            If TypeOf newDevice Is CashDrawer Then
                MyDrawer = DirectCast(newDevice, CashDrawer)
                AddHandler MyDrawer.StatusUpdateEvent, AddressOf Drawer_StatusUpdate
                FormMain.TabControl_Main.SelectedTab = FormMain.TabPage_Main_CashDrawer

            ElseIf TypeOf newDevice Is Msr Then
                MyMSR = DirectCast(newDevice, Msr)
                AddHandler MyMSR.DataEvent, AddressOf MyMSR_DataEvent
                AddHandler MyMSR.ErrorEvent, AddressOf MSR_ErrorEvent
                FormMain.TabControl_Main.SelectedTab = FormMain.TabPage_Main_MSR
            End If

            ' 6. Finalize: Open and Store in Dictionary
            newDevice.Open()
            _activeDevices(type) = newDevice

            RaiseEvent OnLog($"OPOS COMMAND: {type} Device opened via Logical Device Name (LDN): '{logicalName}' (ServiceObject: {selectedDevice.ServiceObjectName})")
            VB.Log($"OPOS COMMAND: {type} Device opened via Logical Device Name (LDN): '{logicalName}' (ServiceObject: {selectedDevice.ServiceObjectName})", LogLevel.Debug)
            RaiseEvent OnStateChanged()

        Catch ex As Exception
            RaiseEvent OnLog($"OPOS COMMAND: Logical Device Name (LDN) Error '{logicalName}' - {ex.Message}")
            VB.Log($"OPOS COMMAND: Logical Device Name (LDN) Error '{logicalName}'", LogLevel.Trace, ex)
        End Try
    End Sub





    Public Sub ClaimDevice(deviceCategory As String, timeout As Integer)
        Dim dev = GetActiveDevice(deviceCategory)
        'Debug.WriteLine($"Attempting to claim device: {deviceCategory}")
        'RaiseEvent OnLog($"Attempting to claim device: {deviceCategory}")

        Dim otherClaimed = GetAnyClaimedCategory()
        If otherClaimed IsNot Nothing AndAlso otherClaimed <> deviceCategory Then
            RaiseEvent OnLog($"SIMULATOR NOTE: {otherClaimed} is already claimed. You may need to release it first.")
            VB.Log($"SIMULATOR NOTE: {otherClaimed} is already claimed. You may need to release it first.", LogLevel.Debug)
        End If

        If dev Is Nothing Then
            RaiseEvent OnLog($"OPOS COMMAND ERROR: Failed to claim - No devices are active. Open a device first.")
            VB.Log($"OPOS COMMAND ERROR: Failed to claim - No devices are active. Open a device first.", LogLevel.Debug)
            Return
        End If

        Try
            ' Check if it's already claimed to avoid unnecessary calls
            If dev.Claimed Then
                RaiseEvent OnLog($"OPOS COMMAND: {deviceCategory} is already claimed.")
                VB.Log($"OPOS COMMAND: {deviceCategory} is already claimed.", LogLevel.Debug)
                Return
            End If

            dev.Claim(timeout)
            RaiseEvent OnLog($"OPOS COMMAND: {deviceCategory} claimed successfully.")
            VB.Log($"OPOS COMMAND: {deviceCategory} claimed successfully.", LogLevel.Debug)

        Catch ex As PosControlException
            RaiseEvent OnLog($"OPOS COMMAND ERROR: [{ex.ErrorCode}] {ex.Message} for {deviceCategory}")
            VB.Log($"OPOS COMMAND ERROR: [{ex.ErrorCode}] {ex.Message} for {deviceCategory}", LogLevel.Trace, ex)
        Catch ex As Exception
            RaiseEvent OnLog($"OPOS COMMAND ERROR: {ex.Message} for {deviceCategory}")
            VB.Log($"OPOS COMMAND ERROR: for {deviceCategory}", LogLevel.Trace, ex)
        Finally
            RaiseEvent OnStateChanged()
        End Try
    End Sub




    Public Function GetAnyClaimedCategory() As String
        For Each kvp In _activeDevices
            If kvp.Value.Claimed Then Return kvp.Key
        Next
        Return Nothing
    End Function





    Public Sub SetEnabled(deviceCategory As String, enable As Boolean)
        Dim dev = GetActiveDevice(deviceCategory)
        If dev Is Nothing Then
            RaiseEvent OnLog($"OPOS COMMAND ERROR: Enable failed. No devices are active. Open and Claim a device first.")
            VB.Log($"OPOS COMMAND ERROR: Enable failed. No devices are active. Open and Claim a device first.", LogLevel.Debug)
            Return
        End If

        Try
            If Not dev.Claimed AndAlso enable Then
                RaiseEvent OnLog($"OPOS COMMAND ERROR: Device '{deviceCategory}' must be Claimed before it can be Enabled.")
                VB.Log($"OPOS COMMAND ERROR: Device '{deviceCategory}' must be Claimed before it can be Enabled.", LogLevel.Debug)
                Return
            End If

            dev.DeviceEnabled = enable
            RaiseEvent OnLog($"OPOS COMMAND: {deviceCategory} DeviceEnabled set to: {enable}")
            VB.Log($"OPOS COMMAND: {deviceCategory} DeviceEnabled set to: {enable}", LogLevel.Debug)

            ' Handle MSR Auto-arm specifically if this is an MSR
            If TypeOf dev Is Msr Then
                Dim m = DirectCast(dev, Msr)
                Try
                    m.DataEventEnabled = (enable And KeepMsrArmed)
                    RaiseEvent OnLog("OPOS COMMAND: MSR DataEvents enabled successfully.")
                    VB.Log("OPOS COMMAND: MSR DataEvents enabled successfully.", LogLevel.Debug)
                    RaiseEvent OnMsrConfigChanged(m.DataEventEnabled)
                Catch ex As Exception
                    RaiseEvent OnLog("OPOS COMMAND ERRROR: MSR DataEvents failed to enable! " & ex.Message)
                    VB.Log("OPOS COMMAND ERRROR: MSR DataEvents failed to enable! ", LogLevel.Trace, ex)
                End Try
            End If

        Catch ex As PosControlException
            RaiseEvent OnLog($"OPOS COMMAND ERROR: [{ex.ErrorCode}] {ex.Message} for '{deviceCategory}'")
            VB.Log($"OPOS COMMAND ERROR: [{ex.ErrorCode}] for '{deviceCategory}'", LogLevel.Trace, ex)
        Catch ex As Exception
            RaiseEvent OnLog($"OPOS COMMAND ERROR: {ex.Message}")
            VB.Log($"OPOS COMMAND ERROR: ", LogLevel.Trace, ex)
        Finally
            RaiseEvent OnStateChanged()
        End Try
    End Sub



    'Private Sub BroadcastMsrSettings(isArmed As Boolean)
    '    Dim json = $"{{ ""type"": ""MSR_CONFIG"", ""armed"": {isArmed.ToString().ToLower()} }}"
    '    ' Send this JSON using your existing WebSocket broadcast logic
    'End Sub



    Public Sub ReleaseDevice(deviceCategory As String)
        Dim dev = GetActiveDevice(deviceCategory)

        If dev Is Nothing Then
            RaiseEvent OnLog($"OPOS COMMAND ERROR: Release failed. No devices are active - nothing to release. Open and Claim a device first.")
            VB.Log($"OPOS COMMAND ERROR: Release failed. No devices are active - nothing to release. Open and Claim a device first.", LogLevel.Debug)
            Return
        End If

        Try
            If dev.Claimed Then
                ' Best Practice: Always disable before releasing
                If dev.DeviceEnabled Then
                    dev.DeviceEnabled = False
                End If

                dev.Release()
                RaiseEvent OnLog($"OPOS COMMAND: Successfully released '{dev.DeviceName}'")
                VB.Log($"OPOS COMMAND: Successfully released '{dev.DeviceName}'", LogLevel.Debug)
            Else
                RaiseEvent OnLog($"OPOS COMMAND ERROR: Release failed because '{dev.DeviceName}' is not currently Claimed.")
                VB.Log($"OPOS COMMAND ERROR: Release failed because '{dev.DeviceName}' is not currently Claimed.", LogLevel.Debug)
            End If

        Catch ex As Exception
            RaiseEvent OnLog($"OPOS COMMAND ERROR: {ex.Message}")
            VB.Log($"OPOS COMMAND ERROR: ", LogLevel.Trace, ex)
        Finally
            RaiseEvent OnStateChanged()
        End Try
    End Sub




    Public Sub ReleaseAllDevices()
        Try
            ' Unhook Events 
            If MyDrawer IsNot Nothing Then
                RemoveHandler MyDrawer.StatusUpdateEvent, AddressOf Drawer_StatusUpdate
            End If

            If MyMSR IsNot Nothing Then
                RemoveHandler MyMSR.DataEvent, AddressOf MyMSR_DataEvent
                RemoveHandler MyMSR.ErrorEvent, AddressOf MSR_ErrorEvent
            End If

            CloseAllDevices()

            explorer = Nothing
            RaiseEvent OnLog("OPOS COMMAND: All devices released and explorer cleared.")
            VB.Log("OPOS COMMAND: All devices released and explorer cleared.", LogLevel.Debug)

        Catch ex As Exception
            RaiseEvent OnLog("OPOS COMMAND ERROR: Error releasing All devices at once: " & ex.Message)
            VB.Log("OPOS COMMAND ERROR: Error releasing All devices at once: ", LogLevel.Trace, ex)
        End Try
    End Sub



    Public Sub CloseAllDevices()
        'Dim keys = _activeDevices.Keys.ToList()
        'For Each key In keys
        '    CloseDeviceByType(key)
        'Next
        'RaiseEvent OnLog("OPOS CLOSE ALL: All devices closed successfully")

        ' V2
        Try
            'VB.Log("OPOS: Close all devices", LogLevel.Debug)

            ' 1. Snapshot the keys to avoid "Collection Modified" errors
            Dim keys = _activeDevices.Keys.ToList()

            If keys.Count = 0 Then
                RaiseEvent OnLog("OPOS COMMAND: Close all skipped - No active devices to close.")
                VB.Log("OPOS COMMAND: Close all skipped - No active devices to close.", LogLevel.Debug)
                Return
            End If

            RaiseEvent OnLog("CLOSING ACTIVE DEVICES:")
            VB.Log("CLOSING ACTIVE DEVICES:", LogLevel.Debug)
            For Each key In keys
                Try
                    ' 2. Attempt to close each specific device type
                    CloseDeviceByType(key)
                    'VB.Log("   CLOSED: " & key, LogLevel.Debug)
                Catch ex As Exception
                    ' We catch inside the loop so one failure doesn't stop the rest
                    RaiseEvent OnLog($"OPOS COMMAND ERROR: Failed to close {key}: {ex.Message}")
                    VB.Log($"OPOS COMMAND ERROR: Failed to close {key}:", LogLevel.Trace, ex)
                End Try
            Next

            RaiseEvent OnLog("All OPOS devices closed successfully")
            VB.Log("All OPOS devices closed successfully", LogLevel.Debug)

        Catch ex As Exception
            ' This catches major failures like a null reference on the list itself
            RaiseEvent OnLog("OPOS COMMAND ERROR: " & ex.Message)
            VB.Log("OPOS COMMAND ERROR: ", LogLevel.Trace, ex)
        Finally
            ' 3. Ensure the dictionary is actually empty even if logic failed
            _activeDevices.Clear()
            RaiseEvent OnStateChanged()
        End Try
    End Sub




    Public Sub CloseDeviceByType(deviceCategory As String)
        If _activeDevices.ContainsKey(deviceCategory) Then
            Dim dev = _activeDevices(deviceCategory)

            If dev Is Nothing Then
                RaiseEvent OnLog($"OPOS COMMAND: Close Failed. No devices are active - nothing to close. Open a device first.")
                VB.Log($"OPOS COMMAND: Close Failed. No devices are active - nothing to close. Open a device first.", LogLevel.Debug)
                Return
            End If

            Try
                ' 2. Unhook specific events and clear shortcuts
                ' This is vital so the UI doesn't try to call a closed object
                If TypeOf dev Is CashDrawer Then
                    RemoveHandler DirectCast(dev, CashDrawer).StatusUpdateEvent, AddressOf Drawer_StatusUpdate
                    MyDrawer = Nothing
                ElseIf TypeOf dev Is Msr Then
                    RemoveHandler DirectCast(dev, Msr).DataEvent, AddressOf MyMSR_DataEvent
                    RemoveHandler DirectCast(dev, Msr).ErrorEvent, AddressOf MSR_ErrorEvent
                    MyMSR = Nothing
                ElseIf TypeOf dev Is Keylock Then
                    MyKeylock = Nothing
                End If

                ' 3. Physical Teardown
                ' We check State to ensure we don't call methods on a device already closed
                If dev.State <> ControlState.Closed Then
                    ' Always disable before releasing
                    If dev.DeviceEnabled Then
                        dev.DeviceEnabled = False
                    End If

                    ' Always release before closing
                    If dev.Claimed Then
                        dev.Release()
                    End If

                    dev.Close()
                End If

                RaiseEvent OnLog($"OPOS COMMAND: Device closed: {deviceCategory}")
                VB.Log($"OPOS COMMAND: Device closed: {deviceCategory}", LogLevel.Debug)

            Catch ex As Exception
                RaiseEvent OnLog($"OPOS COMMAND ERROR: {ex.Message} for {deviceCategory}")
                VB.Log($"OPOS COMMAND ERROR: for {deviceCategory}", LogLevel.Trace, ex)
            Finally
                _activeDevices.Remove(deviceCategory)
                RaiseEvent OnStateChanged()
            End Try
        End If
    End Sub





    Public Sub Dispose() Implements IDisposable.Dispose
        Try
            Dim keys = _activeDevices.Keys.ToList()
            For Each key In keys
                CloseDeviceByType(key)
            Next
            If explorer IsNot Nothing Then
                explorer = Nothing
            End If
        Catch
            ' SUPPRESS ERRORS
        End Try
    End Sub




    ' -- DEVICE SPECIFIC ACTIONS --
    Public Sub OpenCashDrawer()
        Try
            If MyDrawer Is Nothing Then
                RaiseEvent OnLog("ACTION ERROR: No Cash Drawer device is active. Select a device then Open, Claim and Enable it first.")
                VB.Log("ACTION ERROR: No Cash Drawer device is active. Select a device then Open, Claim and Enable it first.", LogLevel.Debug)
                Return
            End If

            If Not MyDrawer.Claimed Then
                RaiseEvent OnLog($"ACTION ERROR: Cash Drawer must be Claimed before physically opening the Drawer.")
                VB.Log($"ACTION ERROR: Cash Drawer must be Claimed before physically opening the Drawer.", LogLevel.Debug)
                Return
            End If

            If Not MyDrawer.DeviceEnabled Then
                RaiseEvent OnLog("ACTION ERROR: Cash Drawer must be Enabled before physically opening the Drawer.")
                VB.Log("ACTION ERROR: Cash Drawer must be Enabled before physically opening the Drawer.", LogLevel.Debug)
                Return
            End If

            RaiseEvent OnLog("ACTION: OpenDrawer() [physically]")
            VB.Log("ACTION: OpenDrawer() [physically]", LogLevel.Debug)
            MyDrawer.OpenDrawer()

        Catch ex As PosControlException
            RaiseEvent OnLog($"ACTION ERROR: Hardware Error when physically opening Cash Drawer: [{ex.ErrorCode}] {ex.Message}")
            VB.Log($"ACTION ERROR: Hardware Error when physically opening Cash Drawer: [{ex.ErrorCode}]", LogLevel.Trace, ex)
        Catch ex As Exception
            RaiseEvent OnLog("ACTION ERROR: System Error: " & ex.Message)
            VB.Log("ACTION ERROR: System Error: ", LogLevel.Trace, ex)
        Finally
            RaiseEvent OnStateChanged()
        End Try
    End Sub



    Public Sub QueryDrawerStatus()
        'Try
        '    If MyDrawer Is Nothing Then
        '        RaiseEvent OnLog("STATUS ERROR: No Cash Drawer instance active.")
        '        Return
        '    End If

        '    If Not MyDrawer.DeviceEnabled Then
        '        RaiseEvent OnLog("STATUS ERROR: Device must be Enabled to query hardware sensors.")
        '        Return
        '    End If

        '    If Not MyDrawer.CapStatus Then
        '        RaiseEvent OnLog("STATUS: Capability: This device does not support status reporting (No sensor).")
        '        Return
        '    End If

        '    Dim status As String = If(MyDrawer.DrawerOpened, "OPEN", "CLOSED")
        '    RaiseEvent OnLog("STATUS: Cash Drawer hardware status: " & status)

        'Catch ex As Exception
        '    RaiseEvent OnLog("STATUS ERROR: status check failed: " & ex.Message)
        'Finally
        '    RaiseEvent OnStateChanged()
        'End Try

        Try
            If MyDrawer Is Nothing Then
                RaiseEvent OnLog("STATUS ERROR: No Cash Drawer instance active.")
                Return
            End If

            If Not MyDrawer.DeviceEnabled Then
                RaiseEvent OnLog("STATUS ERROR: Device must be Enabled to query hardware sensors.")
                Return
            End If

            ' Some virtual drivers or cheap drawers don't support sensor reporting
            If Not MyDrawer.CapStatus Then
                RaiseEvent OnLog("STATUS: Capability: This device does not support status reporting (No sensor).")
                ' We send a "False" status just to clear any stuck "Open" indicators on the web
                RaiseEvent OnDrawerStatus(False)
                Return
            End If

            ' 1. Read the actual hardware property
            Dim isOpen As Boolean = MyDrawer.DrawerOpened
            Dim statusText As String = If(isOpen, "OPEN", "CLOSED")

            ' 2. Log to the Desktop (EPOSCore)
            RaiseEvent OnLog("STATUS: Cash Drawer hardware status: " & statusText)

            ' 3. --- THE MISSING LINK ---
            ' Manually fire the event that pos_OnDrawerStatus is waiting for.
            ' This ensures the WebSocket Server sees the manual query result.
            RaiseEvent OnDrawerStatus(isOpen)

        Catch ex As Exception
            RaiseEvent OnLog("STATUS ERROR: status check failed: " & ex.Message)
        Finally
            RaiseEvent OnStateChanged()
        End Try
    End Sub




    ' -- EVENT HANDLERS --
    Public Sub SetMsrDataEvent(enabled As Boolean)
        ' V1
        'Try
        '    If MyMSR Is Nothing Then
        '        RaiseEvent OnLog("MSR: No devices are active - data events cannot be enabled yet. Open, Claim, and Enable a device first.")
        '        Return
        '    End If

        '    If MyMSR.DeviceEnabled Then
        '        MyMSR.DataEventEnabled = enabled
        '        Dim status = If(enabled, "Armed (Listening)", "Disarmed")
        '        RaiseEvent OnLog($"MSR: Data Events {status}")
        '        RaiseEvent OnMsrConfigChanged(enabled)
        '    Else
        '        RaiseEvent OnLog("MSR ERROR: Cannot enable DataEvents while device is Disabled.")
        '    End If

        '    RaiseEvent OnStateChanged()

        'Catch ex As Exception
        '    RaiseEvent OnLog("MSR ERROR: Config Error: " & ex.Message)
        '    RaiseEvent OnStateChanged()
        'End Try

        'V2
        Try
            ' Update the internal variable first so the logic knows the preference
            _KeepMsrArmed = enabled

            If MyMSR Is Nothing Then
                RaiseEvent OnLog("MSR: No devices are active - data events cannot be enabled yet. Open, Claim, and Enable a device first.")
                ' We still raise the config change so the UI checkboxes "snap back" to unchecked
                RaiseEvent OnMsrConfigChanged(False)
                Return
            End If

            If MyMSR.DeviceEnabled Then
                MyMSR.DataEventEnabled = enabled
                Dim status = If(enabled, "Armed (Listening)", "Disarmed")
                RaiseEvent OnLog($"MSR: Data Events {status}")

                ' This is the crucial "shout" that syncs FormMain and the Web App
                RaiseEvent OnMsrConfigChanged(enabled)
            Else
                RaiseEvent OnLog("MSR ERROR: Cannot enable DataEvents while device is Disabled.")
                ' Snap UI back to off because the hardware command failed
                RaiseEvent OnMsrConfigChanged(False)
            End If

            RaiseEvent OnStateChanged()

        Catch ex As Exception
            RaiseEvent OnLog("MSR ERROR: Config Error: " & ex.Message)
            ' Ensure UI reflects the failure
            RaiseEvent OnMsrConfigChanged(False)
            RaiseEvent OnStateChanged()
        End Try
    End Sub




    Private Sub MyMSR_DataEvent(sender As Object, e As DataEventArgs)
        Try
            Dim useSentinels As Boolean = _MsrIncludeSentinels
            Dim t1 = ProcessTrackData(MyMSR.Track1Data, "%", "?", useSentinels)
            Dim t2 = ProcessTrackData(MyMSR.Track2Data, ";", "?", useSentinels)
            Dim t3 = ProcessTrackData(MyMSR.Track3Data, ";", "?", useSentinels)
            Dim t4 = ProcessTrackData(MyMSR.Track4Data, "", "", useSentinels)

            RaiseEvent OnLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss") & "### MSR CARD SWIPE DETECTED ###")
            RaiseEvent OnMsrDataReceived(t1, t2, t3, t4)

            If _KeepMsrArmed Then
                MyMSR.DataEventEnabled = True
                RaiseEvent OnLog("MSR: KeepDataEventsEnabled = True")
            Else
                RaiseEvent OnLog("MSR: KeepDataEventsEnabled = False")
            End If

            RaiseEvent OnLog("   Track 1:" & vbTab & t1)
            RaiseEvent OnLog("   Track 2:" & vbTab & t2)
            RaiseEvent OnLog("   Track 3:" & vbTab & t3)
            RaiseEvent OnLog("   Track 4:" & vbTab & t4)

            RaiseEvent OnLog("")

            VB.Log("ACTION: MSR SWIPE Detected:", LogLevel.Info)
            VB.Log("   Track 1: " & t1, LogLevel.Info)
            VB.Log("   Track 2: " & t2, LogLevel.Info)
            VB.Log("   Track 3: " & t3, LogLevel.Info)
            VB.Log("   Track 4: " & t4, LogLevel.Info)

        Catch ex As Exception
            RaiseEvent OnLog("ACTION: MSR Data Error: " & ex.Message)
            VB.Log("ACTION: MSR Data Error: ", LogLevel.Trace, ex)
        End Try

        RaiseEvent OnStateChanged()
    End Sub




    Private Sub MSR_ErrorEvent(sender As Object, e As DeviceErrorEventArgs)
        Dim errorMsg As String = $"MSR ERROR: {e.ErrorCode}"
        e.ErrorResponse = ErrorResponse.Clear
        RaiseEvent OnLog(errorMsg)

        ' IMPORTANT: Re-arm  device so it can try again
        ' Without this, the MSR stops sending DataEvents after one error
        If MyMSR IsNot Nothing Then
            Try
                MyMSR.DataEventEnabled = True
                RaiseEvent OnLog("MSR: Listener Re-enabled after error.")
            Catch ex As Exception
                RaiseEvent OnLog("MSR: Failed to re-enable: " & ex.Message)
            End Try
        End If

        RaiseEvent OnStateChanged()
    End Sub




    Private Function ProcessTrackData(data As Byte(), startChar As String, endChar As String, includeSentinels As Boolean) As String
        If data Is Nothing OrElse data.Length = 0 Then Return ""
        Dim result As String = System.Text.Encoding.ASCII.GetString(data).Trim()
        Dim cleanData As String = result.Trim("%"c, ";"c, "?"c, "!"c, "="c)

        If includeSentinels Then
            Return startChar & cleanData & endChar
        Else
            Return cleanData
        End If
    End Function



    Private Sub Drawer_StatusUpdate(sender As Object, e As StatusUpdateEventArgs)
        Dim msg As String = ""
        Select Case e.Status
            Case CashDrawer.StatusClosed
                msg = "Cash Drawer: CLOSED   [physically]"
                RaiseEvent OnDrawerStatus(False)
                VB.Log("Cash Drawer: CLOSED   [physically]", LogLevel.Info)
                VB.Log("", LogLevel.Info)

            Case CashDrawer.StatusOpen
                msg = "Cash Drawer: OPENED   [physically]"
                RaiseEvent OnDrawerStatus(True)
                VB.Log("", LogLevel.Info)
                VB.Log("Cash Drawer: OPENED   [physically]", LogLevel.Info)

            Case Else
                msg = "Cash Drawer: Unknown Status [physically] (" & e.Status.ToString() & ")"
                RaiseEvent OnDrawerStatus(False)
                VB.Log("Cash Drawer: Unknown Status [physically] (" & e.Status.ToString() & ")", LogLevel.Info)
        End Select

        RaiseEvent OnLog(msg)
        RaiseEvent OnStateChanged()
    End Sub



    Public Function GetMsrFeatures() As String
        If MyMSR Is Nothing Then Return "MSR: No device is currently open."

        Dim sb As New StringBuilder()
        sb.AppendLine($"--- MSR CAPABILITIES ---")
        sb.AppendLine($"Device Name: {MyMSR.DeviceName}")
        sb.AppendLine($"Tracks to Read: {MyMSR.TracksToRead}")

        ' Bitwise check for tracks
        sb.AppendLine("Track 1: " & If((MyMSR.TracksToRead And MsrTracks.Track1) = MsrTracks.Track1, "Supported", "Unsupported"))
        sb.AppendLine("Track 2: " & If((MyMSR.TracksToRead And MsrTracks.Track2) = MsrTracks.Track2, "Supported", "Unsupported"))
        sb.AppendLine("Track 3: " & If((MyMSR.TracksToRead And MsrTracks.Track3) = MsrTracks.Track3, "Supported", "Unsupported"))
        sb.AppendLine("Track 4: " & If((MyMSR.TracksToRead And MsrTracks.Track4) = MsrTracks.Track4, "Supported", "Unsupported"))

        sb.AppendLine($"Service Object Version: {MyMSR.ServiceObjectVersion}")
        sb.AppendLine($"Hardware Description: {If(String.IsNullOrEmpty(MyMSR.DeviceDescription), "NULL", MyMSR.DeviceDescription)}")
        sb.AppendLine($"Parse/Decode Data: {MyMSR.ParseDecodeData}")
        sb.AppendLine("--- END CAPABILITIES ---")

        VB.Log("ACTION: GetMsrFeatures:" & vbCrLf & sb.ToString(), LogLevel.Debug)
        Return sb.ToString()
    End Function


    Public Sub SetMsrSentinels(enabled As Boolean)
        Try
            ' Safety Checks
            If MyMSR Is Nothing Then
                VB.Log("ACTION: SetMsrSentinels: No MSR device is currently open.", LogLevel.Debug)
                Throw New Exception("No MSR device is currently open.")
            End If
            If Not MyMSR.Claimed Then
                VB.Log("ACTION: SetMsrSentinels: MSR device not yet claimed.", LogLevel.Debug)
                Throw New Exception("MSR device not yet claimed.")
            End If
            If Not MyMSR.DeviceEnabled Then
                VB.Log("ACTION: SetMsrSentinels: MSR device disabled.", LogLevel.Debug)
                Throw New Exception("MSR device disabled.")
            End If

            ' Apply the setting
            _MsrIncludeSentinels = enabled

            RaiseEvent OnLog($"ACTION: MSR Send Sentinels set to {enabled}")
            VB.Log($"ACTION: MSR Send Sentinels set to {enabled}", LogLevel.Debug)

            ' 2. Notify the WebSocket Server to sync the Web App
            RaiseEvent OnMsrSentinelsChanged(enabled)

        Catch ex As Exception
            ' Notify UI of the failure
            RaiseEvent OnLog("ERROR MSR Set Sentinels: " & ex.Message)
            VB.Log("ERROR MSR Set Sentinels: ", LogLevel.Trace, ex)
            ' Force a sync back to False since it failed
            RaiseEvent OnMsrSentinelsChanged(False)
            Throw ' Re-throw so the WinForm can handle its checkbox state
        End Try
    End Sub



    Public Sub ClearMsrTrackBuffers()
        ' If you have internal variables holding track data, clear them here
        ' Then, trigger the broadcast of empty strings
        RaiseEvent OnMsrDataReceived("", "", "", "")
        RaiseEvent OnLog("ACTION: MSR TRACKS CLEARED - Buffers emptied")
        VB.Log("ACTION: MSR TRACKS CLEARED - Buffers emptied", LogLevel.Debug)
    End Sub




End Class