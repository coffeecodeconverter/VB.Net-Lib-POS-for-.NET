﻿

Imports System.Collections.Specialized
Imports System.Data.Odbc
Imports System.Net
Imports System.Net.Mail
Imports System.Net.Sockets
Imports System.Runtime.CompilerServices
Imports System.Runtime.Hosting
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports Microsoft.PointOfService
Imports Newtonsoft.Json




Public Class FormMain

    ' FOR POS for .NET
    Private WithEvents pos As New OposManager()
    Private _isSyncingHardwareState As Boolean = False
    Public _lastSelectedMsrName As String = ""
    Public _lastSelectedDrawerName As String = ""


    ' FOR WebSocketServer 
    Private wsServer As OposWebSocketServer


    ' FOR AppSettings.config 
    Private settings As New AppSettings()




    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        VB.Log("Application Started", LogLevel.Info)
        AddHandler pos.OnMsrSentinelsChanged, AddressOf SyncSentinelsCheckbox
        AddHandler pos.OnMsrConfigChanged, AddressOf SyncKeepArmedCheckbox
        AddHandler pos.OnDrawerStatus, AddressOf pos_OnDrawerStatus

        settings.LoadSettings_FromFile()

        ' Sync the Logger with your JSON settings immediately
        VB.LogFileName = settings.LogFileName
        VB.OutputDirectory = If(String.IsNullOrEmpty(settings.LogPath),
                        System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs"),
                        settings.LogPath)
        VB.MinimumLevel = settings.MinimumLevel
        VB.RetentionDays = settings.RetentionDays
        VB.Format = If(settings.LogFormat.ToLower() = "ndjson", LogFormat.NDJSON, LogFormat.PlainText)

        HideTabHeaders(TabControl_Main)

        Dim alsoRestartWebSocketServer As Boolean = True

        InitialiseMainApp(alsoRestartWebSocketServer)

        ClearResultsOnMainForm()  ' start cleared
    End Sub




    Private Sub FormMain_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        VB.Log("EVENT: FormMain SHOWN", LogLevel.Debug)
        If settings.StartSilent Then
            Application_Hide()
        End If
    End Sub



    Public Sub Application_Hide()
        VB.Log("HIDE: EPOSCore", LogLevel.Info)
        Me.WindowState = FormWindowState.Minimized
        Me.Hide()
    End Sub


    Public Sub Application_Show()
        VB.Log("SHOW: EPOSCore", LogLevel.Info)
        Me.Show()
        If Me.WindowState = FormWindowState.Minimized Then
            Me.WindowState = FormWindowState.Normal
        End If
        Me.BringToFront()
        Me.Activate()
        VB.Log("SHOW: EPOSCore window brought to front (in-focus)", LogLevel.Debug)
    End Sub





    Private Sub ApplySettingsToUI()
        TextBox_WebSocketServer_Port.Text = settings.WebSocketPort.ToString()
    End Sub






    Private Sub WebServer_Start()
        VB.Log("WebSocket Server: Initializing...", LogLevel.Debug)
        If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
            VB.Log("WebSocket Server is already running on Port: " & wsServer.Port, LogLevel.Warn)
            MessageBox.Show("WebSocket Server is already running on Port: " & wsServer.Port, "WebSocket Server is Already Running", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim portNumberToUse As Integer

        If Not Integer.TryParse(TextBox_WebSocketServer_Port.Text, portNumberToUse) Then
            updateStatus_WebSocketServer()
            VB.Log("Please enter a valid numeric port number for WebSocket Server", LogLevel.Warn)
            MessageBox.Show("Please enter a valid numeric port number for WebSocket Server", "Invalid Port for WebSocket Server", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        ' Confirm valid TCP port range
        If portNumberToUse < 1 OrElse portNumberToUse > 65535 Then
            updateStatus_WebSocketServer()
            VB.Log("Invalid Port Number - must be between 1 and 65535.", LogLevel.Warn)
            MessageBox.Show("Invalid Port Number - must be between 1 and 65535.", "Invalid Port", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        'VB.Log("WebSocket Server Port: " & portNumberToUse, LogLevel.Debug)

        ' Check port is available
        If Not IsPortAvailable(portNumberToUse) Then
            updateStatus_WebSocketServer()
            VB.Log("The selected port (" & portNumberToUse & ") is already in use. - Please choose another port.", LogLevel.Warn)
            MessageBox.Show("The selected port (" & portNumberToUse & ") is already in use." & vbCrLf & "Please choose another port.", "Port " & portNumberToUse & " In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Start WebSocket Server
        Try
            'VB.Log("Starting WebSocket Server", LogLevel.Debug)
            wsServer = New OposWebSocketServer(pos, portNumberToUse)
            wsServer.StartWebServer()

            If wsServer.IsRunning Then
                UpdateResults("WebSocket Server ACTIVE on port: " & portNumberToUse)
                updateStatus_WebSocketServer()
                VB.Log("WebSocket Server ACTIVE on port: " & portNumberToUse, LogLevel.Info)
            Else
                UpdateResults("WebSocket Server: OFFLINE - " & wsServer.LastError)
                updateStatus_WebSocketServer()
                VB.Log("WebSocket Server: OFFLINE - " & wsServer.LastError, LogLevel.Info)
                MessageBox.Show(wsServer.LastError, "WebSocket Server Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If

        Catch ex As Exception
            UpdateResults("WebSocket Initialization Failed: " & ex.Message)
            updateStatus_WebSocketServer()
            VB.Log("WebSocket Server Error:", LogLevel.Trace, ex)
            MessageBox.Show("WebSocket Server Error: " & ex.Message, "WebSocket Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub





    Private Sub WebServer_Stop()
        If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
            wsServer.StopWebServer()
            UpdateResults("WebSocket Server: STOPPED")
            updateStatus_WebSocketServer()
        Else
            UpdateResults("WebSocket Server: Not currently running.")
            updateStatus_WebSocketServer()
        End If
    End Sub



    ' PUBLIC so WebSocketServer can access it 
    Public Sub InitialiseMainApp(Optional restartWebSocketServer As Boolean = False)
        VB.Log("Initialising Main App...", LogLevel.Info)

        Try
            If restartWebSocketServer = True Then
                If wsServer IsNot Nothing Then
                    wsServer.StopWebServer()
                    wsServer = Nothing
                End If
            End If


            If pos IsNot Nothing Then
                pos.ReleaseAllDevices()
                ' Note: We don't need to manually set explorer to Nothing here 
                ' because we are about to replace the whole 'pos' object.
            End If

            ' RE-INITIALIZATION
            VB.Log("Loading AppSettings.json...", LogLevel.Debug)
            settings.LoadSettings_FromFile()

            VB.Log("Applying config to UI...", LogLevel.Debug)
            ApplySettingsToUI()
            pos = New OposManager() ' runs "New PosExplorer()" inside OposManager class.

            ' If we DIDN'T restart the server, we MUST update the existing server's 
            ' reference to the new 'pos' object, otherwise it's talking to a ghost.
            If Not restartWebSocketServer AndAlso wsServer IsNot Nothing Then
                wsServer.UpdateManager(pos)
            End If

            ' Populate UI with OPOS Devices
            ComboBox_Devices.DataSource = pos.populateDeviceListByType(DeviceType.CashDrawer)

            If restartWebSocketServer = True Then
                If settings.StartWebSocketOnLaunch Then
                    WebServer_Start()
                End If
            End If

            resetAllUIFields()
            RefreshStateLabels()

        Catch ex As Exception
            VB.Log("Error during Main App Initialization: ", LogLevel.Trace, ex)
            MessageBox.Show("Error during Main App Initialization: " & ex.Message, "Reset Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub




    Private Function GetFocusedDeviceInfo() As DeviceInfo
        If ComboBox_Devices.SelectedItem IsNot Nothing Then
            Return DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
        End If
        Return Nothing
    End Function





    ' CONTEXT MENU STRIP - FOR SYSTEM TRAY 
    Private Sub HideApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HideApplicationToolStripMenuItem.Click
        Application_Hide()
    End Sub

    Private Sub ShowApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowApplicationToolStripMenuItem.Click
        Application_Show()
    End Sub

    Private Sub AppSettingsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AppSettingsToolStripMenuItem1.Click
        ViewForm_AppSettings()
    End Sub

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetToolStripMenuItem.Click
        VB.Log("DIALOG SHOW: CONFIRM: Reset " & thisApp_Name & "? WARNING: This kills any background tasks, services, and processes to re-initialise the ApplicationActivator - Continue?", LogLevel.Debug)
        Dim result As DialogResult = MessageBox.Show("CONFIRM:" & vbCrLf & "Reset " & thisApp_Name & "?" & vbCrLf & vbCrLf & "WARNING:" & vbCrLf & "This kills any background tasks, services, and processes to re-initialise the app" & vbCrLf & "Continue?", "Confirm Reset", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If result = DialogResult.No Then
            VB.Log("DIALOG SHOW: ANSWER: No ", LogLevel.Debug)
            Exit Sub
        End If
        VB.Log("DIALOG SHOW: ANSWER: Yes ", LogLevel.Debug)
        UpdateResults("Shutting down all POS devices for reset...")
        VB.Log("Shutting down all POS devices for reset...", LogLevel.Debug)
        Dim alsoRestartWebSocketServer As Boolean = True
        InitialiseMainApp(alsoRestartWebSocketServer)
    End Sub

    Private Sub AboutToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem1.Click
        showDialog_About()
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem1.Click
        Me.Close()
    End Sub






    ' Menu Strip for FormMain
    Private Async Sub OpenApplicationFolderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenApplicationFolderToolStripMenuItem.Click
        Dim tempFolder As String = AppDomain.CurrentDomain.BaseDirectory
        Dim opened As Boolean = Await OpenFolderAsync(tempFolder)
        If Not opened Then

            VB.Log($"The folder '{tempFolder}' could not be opened." & Environment.NewLine & "Please check that the folder exists and that you have permission to access it.", LogLevel.Debug)

            MessageBox.Show(
                $"The folder '{tempFolder}' could not be opened." & Environment.NewLine &
                "Please check that the folder exists and that you have permission to access it.",
                "Open Folder Failed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            )
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub



    Private Sub ResetUIFieldsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetUIFieldsToolStripMenuItem.Click
        VB.Log("DIALOG SHOW: CONFIRM: - Reset all UI fields?", LogLevel.Debug)
        Dim result As DialogResult = MessageBox.Show("CONFIRM:" & vbCrLf & "Reset all UI fields?", "Reset UI?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.No Then
            VB.Log("DIALOG SHOW: ANSWER: No", LogLevel.Debug)
            Exit Sub
        End If
        VB.Log("DIALOG SHOW: ANSWER: Yes", LogLevel.Debug)
        Dim alsoRestartWebSocketServer As Boolean = False
        InitialiseMainApp(alsoRestartWebSocketServer)
        resetAllUIFields()
        WebServer_Stop()
        ClearResultsOnMainForm()
    End Sub




    Private Async Sub ConfigFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConfigFileToolStripMenuItem.Click
        Dim tempFile As String = AppSettings.ConfigPath
        Dim opened As Boolean = Await OpenFileAsync(tempFile)
        If Not opened Then

            VB.Log($"The Config File '{tempFile}' could not be opened." & Environment.NewLine & "Please check the file exists and that you have permission to access it.", LogLevel.Debug)

            MessageBox.Show(
                $"The Config File '{tempFile}' could not be opened." & Environment.NewLine &
                "Please check the file exists and that you have permission to access it.",
                "Open Config File Failed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            )
        End If
    End Sub


    Private Sub HideApplicationToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles HideApplicationToolStripMenuItem1.Click
        Application_Hide()
    End Sub




    Private Async Sub FolderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FolderToolStripMenuItem.Click
        OpenLogFolder()
    End Sub



    Public Async Sub OpenLogFolder()
        Dim tempFolder As String = System.IO.Path.Combine(Application.StartupPath, "Logs")
        Dim opened As Boolean = Await OpenFolderAsync(tempFolder)
        If Not opened Then

            VB.Log($"The folder '{tempFolder}' could not be opened." & Environment.NewLine & "Please check that the folder exists and that you have permission to access it.", LogLevel.Debug)

            MessageBox.Show(
                $"The folder '{tempFolder}' could not be opened." & Environment.NewLine &
                "Please check that the folder exists and that you have permission to access it.",
                "Open Folder Failed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            )
        End If
    End Sub



    Private Async Sub FileToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem1.Click
        OpenLogFile()
    End Sub

    Public Async Sub OpenLogFile()
        Dim fileName As String = $"{Date.Today:yyyy-MM-dd}_{VB.LogFileName}.log"
        Dim fullPath As String = System.IO.Path.Combine(Application.StartupPath, "Logs", fileName)
        Dim opened As Boolean = Await OpenFileAsync(fullPath)

        If Not opened Then

            VB.Log($"The Log File '{fullPath}' could not be opened." & Environment.NewLine & "Please check the file exists and that you have permission to access it.", LogLevel.Debug)

            MessageBox.Show(
            $"The Log File '{fullPath}' could not be opened." & Environment.NewLine &
            "Please check the file exists and that you have permission to access it.",
            "Open Log File Failed",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error
        )
        End If
    End Sub


    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        FormSettings.ClearApplicationLogFiles()
    End Sub



    Private Sub AppSettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AppSettingsToolStripMenuItem.Click
        ViewForm_AppSettings()
    End Sub


    Private Sub ViewForm_AppSettings()
        Using frm As New FormSettings(Me.settings)
            If frm.ShowDialog() = DialogResult.OK Then
                ApplySettingsToUI()
                UpdateResults("Settings updated successfully.")
            End If
        End Using
    End Sub



    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        showDialog_About()
    End Sub

    Private Sub showDialog_About()
        MessageBox.Show("OPOS App Version " & thisApp_Version, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub



    Private Sub TextBox_WebSocketServer_Port_TextChanged(sender As Object, e As EventArgs) Handles TextBox_WebSocketServer_Port.TextChanged
        ' DONT USE THIS EVENT
    End Sub

    Private Sub TextBox_WebSocketServer_Port_Click(sender As Object, e As EventArgs) Handles TextBox_WebSocketServer_Port.Click
        ViewForm_AppSettings()
    End Sub

    Private Sub Button_WebSocketServer_Start_Click(sender As Object, e As EventArgs) Handles Button_WebSocketServer_Start.Click
        WebServer_Start()
    End Sub

    Private Sub updateStatus_WebSocketServer()
        If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
            Label_WebSocketServer_Status.Text = "Server Running on Port: " & wsServer.Port
            Label_WebSocketServer_Status.ForeColor = Color.Green
        Else
            Label_WebSocketServer_Status.Text = "Server Stopped"
            Label_WebSocketServer_Status.ForeColor = Color.Red
        End If
    End Sub


    Private Async Sub Button_WebSocketServer_Test_Click(sender As Object, e As EventArgs) Handles Button_WebSocketServer_Test.Click
        Dim opened As Boolean = Await OpenFileAsync(thisApp_WebSocketTesterAppPath)
        If Not opened Then

            VB.Log("The Mini Web App tester could not be opened. FILE: " & thisApp_WebSocketTesterAppPath & ". Please check the file exists and that you have permission to access it.", LogLevel.Debug)

            MessageBox.Show(
                "The Mini Web App tester could not be opened." & vbCrLf & vbCrLf & thisApp_WebSocketTesterAppPath & vbCrLf & vbCrLf &
                "Please check the file exists and that you have permission to access it.",
                "Open Mini Web App Failed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            )
        End If
    End Sub


    Private Sub Button_WebSocketServer_Stop_Click(sender As Object, e As EventArgs) Handles Button_WebSocketServer_Stop.Click
        WebServer_Stop()
    End Sub


    Private Function IsPortAvailable(port As Integer) As Boolean
        Try
            Dim listener As New TcpListener(IPAddress.Loopback, port)
            listener.Start()
            listener.Stop()
            VB.Log($"Port '{port}' is available...", LogLevel.Debug)
            Return True
        Catch ex As SocketException
            VB.Log($"Port '{port}' is already is use - choose a different port", LogLevel.Trace, ex)
            Return False
        End Try
    End Function





    Private Sub pos_OnLog(msg As String) Handles pos.OnLog
        If Me.IsDisposed OrElse Me.Disposing Then Return
        UpdateResults(msg)

        If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
            Dim logJson = JsonConvert.SerializeObject(New With {
                .type = "LOG",
                .message = msg
            })
            wsServer.BroadcastLog(logJson)
        End If
    End Sub





    '' V2
    'Public Sub pos_OnStateChanged() Handles pos.OnStateChanged
    '    If Me.IsDisposed OrElse Me.Disposing Then Return

    '    Me.Invoke(Sub()
    '                  _isSyncingHardwareState = True

    '                  Try

    '                      ' --- 1. NEW AUTO-SELECT LOGIC ---
    '                      ' Check what is actually active in the manager right now
    '                      Dim currentTabCat = If(TabControl_Main.SelectedTab Is TabPage_Main_MSR, DeviceType.Msr, DeviceType.CashDrawer)

    '                      If thisApp_DevDebugMode = True Then
    '                          Debug.WriteLine("DEBUG_MSG: CALLING: pos.GetActiveDevice(currentTabCat) inside pos_OnStateChanged")
    '                      End If

    '                      Dim activeDev = pos.GetActiveDevice(currentTabCat)

    '                      If activeDev IsNot Nothing Then
    '                          ' Update our memory variables so the UI knows the "Last Selected" is now this active device
    '                          If currentTabCat = DeviceType.Msr Then
    '                              If String.IsNullOrEmpty(_lastSelectedMsrName) OrElse _lastSelectedMsrName.Contains("Simulator") Then
    '                                  ' Only fallback to DeviceName if we have nothing better
    '                                  _lastSelectedMsrName = activeDev.DeviceName
    '                              End If
    '                          Else
    '                              If String.IsNullOrEmpty(_lastSelectedDrawerName) OrElse _lastSelectedDrawerName.Contains("Simulator") Then
    '                                  _lastSelectedDrawerName = activeDev.DeviceName
    '                              End If
    '                          End If

    '                          ' Force the ComboBox to jump to this device if it isn't already selected
    '                          UpdateComboBoxForCategory(currentTabCat.ToString())
    '                      End If
    '                      ' --------------------------------

    '                      ' 2. YOUR EXISTING LOGIC
    '                      RefreshStateLabels()

    '                      Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
    '                      Dim dev As PosCommon = Nothing


    '                      If thisApp_DevDebugMode = True Then
    '                          Debug.WriteLine("DEBUG_MSG: CALLING: pos.GetActiveDevice(info.Type) inside pos_OnStateChanged")
    '                      End If

    '                      If info IsNot Nothing Then
    '                          dev = pos.GetActiveDevice(info.Type)
    '                      End If

    '                      If dev Is Nothing Then
    '                          CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
    '                          CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
    '                          CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
    '                      Else
    '                          CheckBox_OPOSToolbar_DeviceEnabled.Checked = dev.DeviceEnabled

    '                          ' Special MSR handling
    '                          If TypeOf dev Is Msr Then
    '                              Dim myMsr = DirectCast(dev, Msr)
    '                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = True
    '                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = myMsr.DataEventEnabled
    '                          Else
    '                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
    '                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
    '                          End If
    '                      End If

    '                      ' --- WebSocket Status Broadcasts ---
    '                      If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
    '                          ' Define the list of all categories the Web App tracks
    '                          Dim allCategories = {DeviceType.CashDrawer, DeviceType.Msr, DeviceType.Keylock}

    '                          For Each catType In allCategories

    '                              If thisApp_DevDebugMode = True Then
    '                                  Debug.WriteLine("DEBUG_MSG: CALLING: pos.GetActiveDevice(catType) inside pos_OnStateChanged")
    '                              End If

    '                              Dim activeItem = pos.GetActiveDevice(catType)
    '                              Dim catName As String = catType.ToString()

    '                              If activeItem Is Nothing Then
    '                                  ' If no device is active, clear the web app's LDN and turn lights OFF
    '                                  wsServer.BroadcastStatus(catName, "ldn", "")
    '                                  wsServer.BroadcastStatus(catName, "State_Open", False)
    '                                  wsServer.BroadcastStatus(catName, "State_Claimed", False)
    '                                  wsServer.BroadcastStatus(catName, "State_Enabled", False)
    '                              Else

    '                                  Dim actualLDN As String = ""
    '                                  ' A. Try to find the LDN from the ComboBox items FIRST
    '                                  ' This is the most reliable way to get "OPOSDRW1"
    '                                  For Each item In ComboBox_Devices.Items
    '                                      Dim childInfo = TryCast(item, DeviceInfo)
    '                                      If childInfo IsNot Nothing AndAlso childInfo.Type = catType AndAlso childInfo.ServiceObjectName = activeItem.DeviceName Then
    '                                          If childInfo.LogicalNames IsNot Nothing AndAlso childInfo.LogicalNames.Length > 0 Then
    '                                              actualLDN = childInfo.LogicalNames(0)
    '                                              Exit For
    '                                          End If
    '                                      End If
    '                                  Next

    '                                  ' B. Fallback to Memory Variables if the ComboBox didn't have it
    '                                  If String.IsNullOrEmpty(actualLDN) Then
    '                                      actualLDN = If(catType = DeviceType.Msr, _lastSelectedMsrName, _lastSelectedDrawerName)
    '                                  End If

    '                                  ' C. Final safety check (If both above failed)
    '                                  If String.IsNullOrEmpty(actualLDN) Then actualLDN = activeItem.DeviceName

    '                                  ' --- BROADCAST ---
    '                                  Debug.WriteLine($"BRAODCASTING BACK TO WEB APP - LDN: {actualLDN}")
    '                                  wsServer.BroadcastStatus(catName, "ldn", actualLDN)


    '                                  ' 2. BROADCAST THE STATES (This turns on the web lights)
    '                                  wsServer.BroadcastStatus(catName, "State_Open", (activeItem.State <> ControlState.Closed))
    '                                  wsServer.BroadcastStatus(catName, "State_Claimed", activeItem.Claimed)
    '                                  wsServer.BroadcastStatus(catName, "State_Enabled", activeItem.DeviceEnabled)
    '                              End If
    '                          Next
    '                      End If

    '                  Catch ex As Exception
    '                      Debug.WriteLine("Error during pos_OnStateChanged(): " & ex.Message)
    '                  Finally
    '                      _isSyncingHardwareState = False
    '                  End Try
    '              End Sub)
    'End Sub



    Public Sub pos_OnStateChanged() Handles pos.OnStateChanged
        If Me.IsDisposed OrElse Me.Disposing Then Return

        Me.Invoke(Sub()
                      ' Prevent recursive UI events from re-triggering this logic
                      If _isSyncingHardwareState Then Return
                      _isSyncingHardwareState = True

                      Try
                          ' --- 1. CONTEXT SETUP ---
                          Dim currentTabCatType = If(TabControl_Main.SelectedTab Is TabPage_Main_MSR, DeviceType.Msr, DeviceType.CashDrawer)
                          Dim activeDev = pos.GetActiveDevice(currentTabCatType, "StateChanged_MASTER")

                          ' --- 2. AUTO-SELECT / COMBOBOX SYNC ---
                          If activeDev IsNot Nothing Then
                              ' Update memory variables
                              If currentTabCatType = DeviceType.Msr Then
                                  If String.IsNullOrEmpty(_lastSelectedMsrName) OrElse _lastSelectedMsrName.Contains("Simulator") Then
                                      _lastSelectedMsrName = activeDev.DeviceName
                                  End If
                              Else
                                  If String.IsNullOrEmpty(_lastSelectedDrawerName) OrElse _lastSelectedDrawerName.Contains("Simulator") Then
                                      _lastSelectedDrawerName = activeDev.DeviceName
                                  End If
                              End If

                              ' This triggers ComboBox logic - we use the cat string
                              UpdateComboBoxForCategory(currentTabCatType.ToString())
                          End If



                          '''''' --- 3. UI REFRESH ---
                          '''''' We call this once. Internal labels will now be updated.
                          '''''RefreshStateLabels(activeDev)

                          '''''' Sync the Toolbar Checkboxes based on the device selected in the ComboBox
                          '''''Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
                          '''''If info IsNot Nothing Then
                          '''''    ' Look up the device for the current selected item in the list
                          '''''    Dim currentListDev = pos.GetActiveDevice(info.Type, "StateChanged_Section2")

                          '''''    If currentListDev Is Nothing Then
                          '''''        CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
                          '''''        CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
                          '''''        CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
                          '''''    Else
                          '''''        CheckBox_OPOSToolbar_DeviceEnabled.Checked = currentListDev.DeviceEnabled

                          '''''        If TypeOf currentListDev Is Msr Then
                          '''''            Dim myMsr = DirectCast(currentListDev, Msr)
                          '''''            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = True
                          '''''            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = myMsr.DataEventEnabled
                          '''''        Else
                          '''''            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
                          '''''            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
                          '''''        End If
                          '''''    End If
                          '''''End If

                          ' --- 3. UI REFRESH ---
                          RefreshStateLabels(activeDev)

                          ' Sync the Toolbar Checkboxes
                          ' Instead of looking up a "currentListDev", we just check if the ComboBox 
                          ' matches the category of the device we already have in 'activeDev'
                          Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)

                          If info IsNot Nothing AndAlso activeDev IsNot Nothing AndAlso info.Type = currentTabCatType Then
                              ' 1. Logic for when the UI matches the Active Hardware
                              CheckBox_OPOSToolbar_DeviceEnabled.Checked = activeDev.DeviceEnabled

                              If TypeOf activeDev Is Msr Then
                                  Dim myMsr = DirectCast(activeDev, Msr)
                                  CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = True
                                  CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = myMsr.DataEventEnabled
                              Else
                                  CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
                                  CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
                              End If

                          Else
                              ' 2. Logic for when the device is closed or the tab doesn't match
                              CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
                              CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
                          End If

                          '' --- 4. WebSocket Status Broadcasts ---
                          'If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
                          '    Dim allCategories = {DeviceType.CashDrawer, DeviceType.Msr, DeviceType.Keylock}

                          '    For Each catType In allCategories
                          '        ' Look up device ONCE per loop iteration
                          '        Dim loopDev = pos.GetActiveDevice(catType)
                          '        Dim catName As String = catType.ToString()

                          '        If loopDev Is Nothing Then
                          '            wsServer.BroadcastStatus(catName, "ldn", "")
                          '            wsServer.BroadcastStatus(catName, "State_Open", False)
                          '            wsServer.BroadcastStatus(catName, "State_Claimed", False)
                          '            wsServer.BroadcastStatus(catName, "State_Enabled", False)
                          '        Else
                          '            ' Find actual LDN for this active device
                          '            Dim actualLDN As String = ""

                          '            ' Search ComboBox items for a matching Service Object Name
                          '            For Each item In ComboBox_Devices.Items
                          '                Dim childInfo = TryCast(item, DeviceInfo)
                          '                If childInfo IsNot Nothing AndAlso childInfo.Type = catType AndAlso childInfo.ServiceObjectName = loopDev.DeviceName Then
                          '                    If childInfo.LogicalNames?.Length > 0 Then
                          '                        actualLDN = childInfo.LogicalNames(0)
                          '                        Exit For
                          '                    End If
                          '                End If
                          '            Next

                          '            ' Fallback to memory if not in combo
                          '            If String.IsNullOrEmpty(actualLDN) Then
                          '                actualLDN = If(catType = DeviceType.Msr, _lastSelectedMsrName, _lastSelectedDrawerName)
                          '            End If

                          '            ' Final fallback to Service Object Name
                          '            If String.IsNullOrEmpty(actualLDN) Then actualLDN = loopDev.DeviceName

                          '            ' Broadcast as a single block of updates for this category
                          '            wsServer.BroadcastStatus(catName, "ldn", actualLDN)
                          '            wsServer.BroadcastStatus(catName, "State_Open", (loopDev.State <> ControlState.Closed))
                          '            wsServer.BroadcastStatus(catName, "State_Claimed", loopDev.Claimed)
                          '            wsServer.BroadcastStatus(catName, "State_Enabled", loopDev.DeviceEnabled)
                          '        End If
                          '    Next
                          'End If


                          ' --- 4. WebSocket Status Broadcasts (Non-Looping) ---
                          If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then

                              ' We only care about the category the user is actually interacting with right now
                              Dim catName As String = currentTabCatType.ToString()

                              ' Look up the device ONCE (activeDev was already fetched at the top of the Sub)
                              ' This uses the object we already have in memory from Section 1
                              If activeDev Is Nothing Then
                                  ' Explicitly broadcast "Empty" state for the current category
                                  wsServer.BroadcastStatus(catName, "ldn", "")
                                  wsServer.BroadcastStatus(catName, "State_Open", False)
                                  wsServer.BroadcastStatus(catName, "State_Claimed", False)
                                  wsServer.BroadcastStatus(catName, "State_Enabled", False)
                              Else
                                  ' Find the LDN for the active device
                                  Dim actualLDN As String = ""

                                  ' Search ComboBox items for the Logical Name
                                  For Each item In ComboBox_Devices.Items
                                      Dim childInfo = TryCast(item, DeviceInfo)
                                      If childInfo IsNot Nothing AndAlso childInfo.Type = currentTabCatType AndAlso childInfo.ServiceObjectName = activeDev.DeviceName Then
                                          If childInfo.LogicalNames?.Length > 0 Then
                                              actualLDN = childInfo.LogicalNames(0)
                                              Exit For
                                          End If
                                      End If
                                  Next

                                  ' Fallbacks
                                  If String.IsNullOrEmpty(actualLDN) Then
                                      actualLDN = If(currentTabCatType = DeviceType.Msr, _lastSelectedMsrName, _lastSelectedDrawerName)
                                  End If
                                  If String.IsNullOrEmpty(actualLDN) Then actualLDN = activeDev.DeviceName

                                  ' Broadcast only the active category
                                  wsServer.BroadcastStatus(catName, "ldn", actualLDN)
                                  wsServer.BroadcastStatus(catName, "State_Open", (activeDev.State <> ControlState.Closed))
                                  wsServer.BroadcastStatus(catName, "State_Claimed", activeDev.Claimed)
                                  wsServer.BroadcastStatus(catName, "State_Enabled", activeDev.DeviceEnabled)
                              End If
                          End If



                      Catch ex As Exception
                          VB.Log($"Error during pos_OnStateChanged()", LogLevel.Trace, ex)
                          Debug.WriteLine("Error during pos_OnStateChanged(): " & ex.Message)
                      Finally
                          _isSyncingHardwareState = False
                      End Try
                  End Sub)
    End Sub




    ' Device List Buttons 
    Private Sub Button_DeviceList_CashDrawer_Click(sender As Object, e As EventArgs) Handles Button_DeviceList_CashDrawer.Click
        TabControl_Main.SelectedTab = TabPage_Main_CashDrawer
        VB.Log($"CATEGORY CHANGED TO: CashDrawer", LogLevel.Debug)
        UpdateResults($"CATEGORY CHANGED TO: CashDrawer")
        UpdateComboBoxForCategory(DeviceType.CashDrawer)
    End Sub


    Private Sub Button_DeviceList_MSR_Click(sender As Object, e As EventArgs) Handles Button_DeviceList_MSR.Click
        TabControl_Main.SelectedTab = TabPage_Main_MSR
        VB.Log($"CATEGORY CHANGED TO: Msr", LogLevel.Debug)
        UpdateResults($"CATEGORY CHANGED TO: Msr")
        UpdateComboBoxForCategory(DeviceType.Msr)
    End Sub


    Private Sub Button_DeviceList_Dallas_Click(sender As Object, e As EventArgs) Handles Button_DeviceList_Dallas.Click
        TabControl_Main.SelectedTab = TabPage_Main_Dallas
        VB.Log($"CATEGORY CHANGED TO: KeyLock (Dallas)", LogLevel.Debug)
        UpdateResults($"CATEGORY CHANGED TO: KeyLock (Dallas)")
        UpdateComboBoxForCategory(DeviceType.Keylock)
    End Sub




    Public Sub UpdateComboBoxForCategory(category As String)
        _isSyncingHardwareState = True ' Prevents event spam during tab switch

        Try
            ' 1. Refresh list of devices for this category
            Dim deviceList = pos.populateDeviceListByType(category)
            ComboBox_Devices.DataSource = deviceList

            ' 2. Determine which LDN we are looking for from memory
            Dim nameToFind = If(category = DeviceType.Msr, _lastSelectedMsrName, _lastSelectedDrawerName)

            Dim foundIndex As Integer = 0 ' Default to first item

            If Not String.IsNullOrEmpty(nameToFind) Then
                For i As Integer = 0 To ComboBox_Devices.Items.Count - 1
                    Dim info = TryCast(ComboBox_Devices.Items(i), DeviceInfo)

                    If info IsNot Nothing Then
                        ' FIX: Check if the saved name matches the ServiceObjectName OR is inside the LogicalNames array
                        Dim isMatch = (info.ServiceObjectName = nameToFind)

                        If Not isMatch AndAlso info.LogicalNames IsNot Nothing Then
                            ' Check if our LDN (e.g. OPOSMSR1) exists in the logical names list
                            isMatch = info.LogicalNames.Contains(nameToFind)
                        End If

                        If isMatch Then
                            foundIndex = i
                            Exit For
                        End If
                    End If
                Next
            End If

            ' 3. Apply the selection
            _isSyncingHardwareState = True ' Set this before changing index
            If ComboBox_Devices.Items.Count > 0 Then
                ComboBox_Devices.SelectedIndex = foundIndex
            Else
                ComboBox_Devices.SelectedIndex = -1
            End If
            _isSyncingHardwareState = False

        Finally
            _isSyncingHardwareState = False
            RefreshStateLabels()
        End Try
    End Sub





    ' OPOS Toolbar 
    Private Sub Button_OPOSToolbar_Open_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_Open.Click
        Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
        pos.OpenDevice(info)
    End Sub



    Private Sub Button_OPOSToolbar_Claim_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_Claim.Click
        Dim info = GetFocusedDeviceInfo()
        If info IsNot Nothing Then
            pos.ClaimDevice(info.Type, 1000)
        Else
            VB.Log("UI ERROR: No device selected in the list to Claim.", LogLevel.Debug)
            UpdateResults("UI ERROR: No device selected in the list to Claim.")
        End If
    End Sub



    Private Sub CheckBox_OPOSToolbar_DeviceEnabled_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_OPOSToolbar_DeviceEnabled.CheckedChanged
        If _isSyncingHardwareState Then Return
        If Not CheckBox_OPOSToolbar_DeviceEnabled.Focused Then
            Return
        End If

        Dim info = GetFocusedDeviceInfo()
        If info IsNot Nothing Then
            pos.SetEnabled(info.Type, CheckBox_OPOSToolbar_DeviceEnabled.Checked)
        End If
    End Sub


    Private Sub CheckBox_OPOSToolbar_KeepDataEventsEnabled_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_OPOSToolbar_KeepDataEventsEnabled.CheckedChanged
        If Not CheckBox_OPOSToolbar_KeepDataEventsEnabled.Focused Then Return
        pos.SetMsrDataEvent(CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked)
    End Sub


    Public Sub SyncKeepArmedCheckbox(enabled As Boolean)
        ' UI updates must happen on the UI thread
        If Me.InvokeRequired Then
            Me.Invoke(Sub() SyncKeepArmedCheckbox(enabled))
            Return
        End If

        ' Remove handler to prevent a recursive loop
        RemoveHandler CheckBox_OPOSToolbar_KeepDataEventsEnabled.CheckedChanged,
                  AddressOf CheckBox_OPOSToolbar_KeepDataEventsEnabled_CheckedChanged

        CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = enabled

        ' Re-attach the handler
        AddHandler CheckBox_OPOSToolbar_KeepDataEventsEnabled.CheckedChanged,
               AddressOf CheckBox_OPOSToolbar_KeepDataEventsEnabled_CheckedChanged
    End Sub




    Private Sub Button_OPOSToolbar_Close_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_Close.Click
        Dim info = GetFocusedDeviceInfo()
        If info IsNot Nothing Then
            pos.CloseDeviceByType(info.Type)
        End If
    End Sub

    Private Sub Button_OPOSToolbar_CloseAll_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_CloseAll.Click
        VB.Log("DIALOG SHOW: CONFIRM: Are you sure you want to close all devices?", LogLevel.Debug)
        Dim result As DialogResult = MessageBox.Show(
            "Are you sure you want to close all devices?",
            "Confirm Action",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        )

        If result = DialogResult.Yes Then
            VB.Log("DIALOG SHOW: ANSWER: Yes", LogLevel.Debug)
            pos.CloseAllDevices()
        Else
            VB.Log("DIALOG SHOW: ANSWER: No", LogLevel.Debug)
        End If
    End Sub


    Private Sub Button_OPOSToolbar_OPOSStatus_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_OPOSStatus.Click
        Dim info = GetFocusedDeviceInfo()
        Dim status = pos.GetDeviceState(info.Type)
        VB.Log("OPOS Status: " & status.Summary, LogLevel.Debug)
        UpdateResults("OPOS Status: " & status.Summary)
    End Sub




    Private Sub Button_OPOSToolbar_Release_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_Release.Click
        Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
        If info IsNot Nothing Then
            pos.ReleaseDevice(info.Type)
        Else
            VB.Log("UI ERROR: Select a device in the list to Release.", LogLevel.Debug)
            UpdateResults("UI ERROR: Select a device in the list to Release.")
        End If
    End Sub





    Private Sub ComboBox_Devices_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_Devices.SelectedIndexChanged
        If _isSyncingHardwareState Then Return
        detectOPOSDeviceSelectionChange()
        RefreshStateLabels()
    End Sub





    Private Sub detectOPOSDeviceSelectionChange()
        Dim info = DirectCast(ComboBox_Devices.SelectedItem, DeviceInfo)
        If info IsNot Nothing Then
            UpdateResults($"DEVICE SELECTION CHANGED TO: {info.ServiceObjectName} ({info.Type})")
            VB.Log($"DEVICE SELECTION CHANGED TO: {info.ServiceObjectName} ({info.Type})", LogLevel.Debug)

            ' --- THE FIX: Save the LDN, not the ServiceObjectName ---
            Dim ldnToSave As String = info.ServiceObjectName ' Fallback
            If info.LogicalNames IsNot Nothing AndAlso info.LogicalNames.Length > 0 Then
                ldnToSave = info.LogicalNames(0)
            End If

            If info.Type = DeviceType.Msr Then
                _lastSelectedMsrName = ldnToSave
            ElseIf info.Type = DeviceType.CashDrawer Then
                _lastSelectedDrawerName = ldnToSave
            End If
        End If
    End Sub



    ' Tab Control Main - Cash Drawer 
    Private Sub Button_MainArea_CashDrawer_OpenDrawer_Click(sender As Object, e As EventArgs) Handles Button_MainArea_CashDrawer_OpenDrawer.Click
        pos.OpenCashDrawer()
    End Sub


    Private Sub Button_MainArea_CashDrawer_GetDrawerState_Click(sender As Object, e As EventArgs) Handles Button_MainArea_CashDrawer_GetDrawerState.Click
        pos.QueryDrawerStatus()
    End Sub



    Private Sub pos_OnDrawerStatus(isOpen As Boolean) Handles pos.OnDrawerStatus
        'If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
        '    ' Push the physical sensor state (true = drawer is physically pulled out)
        '    wsServer.BroadcastStatus("Sensor_PhysicallyOpen", isOpen)
        '    wsServer.BroadcastLog(isOpen)
        'End If

        'If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
        '    ' 1. Keep the status update for your UI lights/logic
        '    wsServer.BroadcastStatus("Sensor_PhysicallyOpen", isOpen)

        '    ' 2. FIX: Send a clear, readable string to the Web Log
        '    Dim logText As String = "DRAWER HARDWARE: " & If(isOpen, "OPEN", "CLOSED")
        '    wsServer.BroadcastLog(logText)
        'End If

        If wsServer IsNot Nothing AndAlso wsServer.IsRunning Then
            ' Pass "CashDrawer" as the first argument
            wsServer.BroadcastStatus("CashDrawer", "Sensor_PhysicallyOpen", isOpen)

            Dim logText As String = "DRAWER HARDWARE: " & If(isOpen, "OPEN", "CLOSED")
            wsServer.BroadcastLog(logText)
        End If
    End Sub



    ' OPOS Status Bar 
    Private Sub Button_OPOSToolbar_ClearResults_Click(sender As Object, e As EventArgs) Handles Button_OPOSToolbar_ClearResults.Click
        ClearResultsOnMainForm()
    End Sub

    Public Sub ClearResultsOnMainForm()
        TextBox_Results.Text = ""
    End Sub

    Private Sub Label_OPOSStatus_OpenState_Click(sender As Object, e As EventArgs) Handles Label_OPOSStatus_OpenState.Click

    End Sub

    Private Sub Label_OPOSStatus_ClaimState_Click(sender As Object, e As EventArgs) Handles Label_OPOSStatus_ClaimState.Click

    End Sub

    Private Sub Label_OPOSStatus_EnableState_Click(sender As Object, e As EventArgs) Handles Label_OPOSStatus_EnableState.Click

    End Sub





    Public Sub UpdateResults(message As String)
        If TextBox_Results.InvokeRequired Then
            TextBox_Results.Invoke(Sub() UpdateResults(message))
        Else
            TextBox_Results.AppendText($"{DateTime.Now:HH:mm:ss} - {message}{vbCrLf}")
            TextBox_Results.SelectionStart = TextBox_Results.Text.Length
            TextBox_Results.ScrollToCaret()
        End If
    End Sub




    '' V1
    'Private Sub RefreshStateLabels()
    '    Dim info = GetFocusedDeviceInfo()

    '    If thisApp_DevDebugMode = True Then
    '        Debug.WriteLine("DEBUG_MSG: CALLING: pos.GetActiveDevice(info.Type) inside RefreshStateLabels() - 1")
    '    End If

    '    If info Is Nothing OrElse pos.GetActiveDevice(info.Type) Is Nothing Then
    '        Label_OPOSStatus_DeviceName.Text = "**NOT ACTIVE**"
    '        Label_OPOSStatus_DeviceName.ForeColor = Color.Red

    '        Label_OPOSStatus_OpenState.Text = "Closed"
    '        Label_OPOSStatus_OpenState.ForeColor = Color.Red

    '        Label_OPOSStatus_ClaimState.Text = "Unclaimed"
    '        Label_OPOSStatus_ClaimState.ForeColor = Color.Red

    '        Label_OPOSStatus_EnableState.Text = "Disabled"
    '        Label_OPOSStatus_EnableState.ForeColor = Color.Red

    '        Label_OPOSStatus_Summary.Text = "Closed"

    '        _isSyncingHardwareState = True
    '        CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
    '        CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
    '        _isSyncingHardwareState = False
    '        Return
    '    End If

    '    Dim status = pos.GetDeviceState(info.Type)
    '    Label_OPOSStatus_Summary.Text = status.Summary

    '    If thisApp_DevDebugMode = True Then
    '        Debug.WriteLine("DEBUG_MSG: CALLING: pos.GetActiveDevice(info.Type) inside RefreshStateLabels() - 2")
    '    End If

    '    Dim dev = pos.GetActiveDevice(info.Type)

    '    Label_OPOSStatus_DeviceName.Text = dev.DeviceName
    '    Label_OPOSStatus_DeviceName.ForeColor = Color.Blue

    '    Label_OPOSStatus_OpenState.Text = "Open"
    '    Label_OPOSStatus_OpenState.ForeColor = Color.Green

    '    Label_OPOSStatus_ClaimState.Text = If(dev.Claimed, "Claimed", "Unclaimed")
    '    Label_OPOSStatus_ClaimState.ForeColor = If(dev.Claimed, Color.Green, Color.Red)

    '    Label_OPOSStatus_EnableState.Text = If(dev.DeviceEnabled, "Enabled", "Disabled")
    '    Label_OPOSStatus_EnableState.ForeColor = If(dev.DeviceEnabled, Color.Green, Color.Red)


    '    ' Sync the Checkbox without triggering the CheckedChanged event
    '    _isSyncingHardwareState = True
    '    CheckBox_OPOSToolbar_DeviceEnabled.Checked = dev.DeviceEnabled
    '    _isSyncingHardwareState = False
    'End Sub



    ' V3 - NORMAL - KEEP THIS - THERES AN OVERLOADED VERSION TOO! 
    Private Sub RefreshStateLabels()
        Dim info = GetFocusedDeviceInfo()

        ' 1. Capture the device reference ONCE
        Dim dev = If(info IsNot Nothing, pos.GetActiveDevice(info.Type, "RefreshLabels"), Nothing)

        ' 2. Handle the "Not Active" state
        If dev Is Nothing Then
            Label_OPOSStatus_DeviceName.Text = "**NOT ACTIVE**"
            Label_OPOSStatus_DeviceName.ForeColor = Color.Red

            Label_OPOSStatus_OpenState.Text = "Closed"
            Label_OPOSStatus_OpenState.ForeColor = Color.Red

            Label_OPOSStatus_ClaimState.Text = "Unclaimed"
            Label_OPOSStatus_ClaimState.ForeColor = Color.Red

            Label_OPOSStatus_EnableState.Text = "Disabled"
            Label_OPOSStatus_EnableState.ForeColor = Color.Red

            Label_OPOSStatus_Summary.Text = "Closed"

            _isSyncingHardwareState = True
            CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
            _isSyncingHardwareState = False
            Return
        End If

        ' 3. Handle the "Active" state using the 'dev' variable we already have
        ' GetDeviceState likely looks up the device again internally, 
        ' but we've already cut out the two extra calls here.
        Dim status = pos.GetDeviceState(info.Type)
        Label_OPOSStatus_Summary.Text = status.Summary

        Label_OPOSStatus_DeviceName.Text = dev.DeviceName
        Label_OPOSStatus_DeviceName.ForeColor = Color.Blue

        Label_OPOSStatus_OpenState.Text = "Open"
        Label_OPOSStatus_OpenState.ForeColor = Color.Green

        Label_OPOSStatus_ClaimState.Text = If(dev.Claimed, "Claimed", "Unclaimed")
        Label_OPOSStatus_ClaimState.ForeColor = If(dev.Claimed, Color.Green, Color.Red)

        Label_OPOSStatus_EnableState.Text = If(dev.DeviceEnabled, "Enabled", "Disabled")
        Label_OPOSStatus_EnableState.ForeColor = If(dev.DeviceEnabled, Color.Green, Color.Red)

        ' 4. Sync the Toolbar Checkbox
        _isSyncingHardwareState = True
        CheckBox_OPOSToolbar_DeviceEnabled.Checked = dev.DeviceEnabled

        ' Handle MSR specifically if dev is an MSR
        If TypeOf dev Is Msr Then
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = True
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = DirectCast(dev, Msr).DataEventEnabled
        Else
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
        End If
        _isSyncingHardwareState = False
    End Sub




    ' V4 - OVERLOADING KEEP THIS 
    Private Sub RefreshStateLabels(activeDev As PosCommon)
        Dim info = GetFocusedDeviceInfo()

        ' 2. Handle the "Not Active" state
        If activeDev Is Nothing Then
            Label_OPOSStatus_DeviceName.Text = "**NOT ACTIVE**"
            Label_OPOSStatus_DeviceName.ForeColor = Color.Red

            Label_OPOSStatus_OpenState.Text = "Closed"
            Label_OPOSStatus_OpenState.ForeColor = Color.Red

            Label_OPOSStatus_ClaimState.Text = "Unclaimed"
            Label_OPOSStatus_ClaimState.ForeColor = Color.Red

            Label_OPOSStatus_EnableState.Text = "Disabled"
            Label_OPOSStatus_EnableState.ForeColor = Color.Red

            Label_OPOSStatus_Summary.Text = "Closed"

            _isSyncingHardwareState = True
            CheckBox_OPOSToolbar_DeviceEnabled.Checked = False
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = False
            _isSyncingHardwareState = False
            Return
        End If

        ' 3. Handle the "Active" state using the 'dev' variable we already have
        ' GetDeviceState likely looks up the device again internally, 
        ' but we've already cut out the two extra calls here.
        Dim status = pos.GetDeviceState(info.Type)
        Label_OPOSStatus_Summary.Text = status.Summary

        Label_OPOSStatus_DeviceName.Text = activeDev.DeviceName
        Label_OPOSStatus_DeviceName.ForeColor = Color.Blue

        Label_OPOSStatus_OpenState.Text = "Open"
        Label_OPOSStatus_OpenState.ForeColor = Color.Green

        Label_OPOSStatus_ClaimState.Text = If(activeDev.Claimed, "Claimed", "Unclaimed")
        Label_OPOSStatus_ClaimState.ForeColor = If(activeDev.Claimed, Color.Green, Color.Red)

        Label_OPOSStatus_EnableState.Text = If(activeDev.DeviceEnabled, "Enabled", "Disabled")
        Label_OPOSStatus_EnableState.ForeColor = If(activeDev.DeviceEnabled, Color.Green, Color.Red)

        ' 4. Sync the Toolbar Checkbox
        _isSyncingHardwareState = True
        CheckBox_OPOSToolbar_DeviceEnabled.Checked = activeDev.DeviceEnabled

        ' Handle MSR specifically if dev is an MSR
        If TypeOf activeDev Is Msr Then
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = True
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Checked = DirectCast(activeDev, Msr).DataEventEnabled
        Else
            CheckBox_OPOSToolbar_KeepDataEventsEnabled.Enabled = False
        End If
        _isSyncingHardwareState = False
    End Sub





    Private Sub pos_OnMsrDataReceived(t1 As String, t2 As String, t3 As String, t4 As String) Handles pos.OnMsrDataReceived
        If Me.IsDisposed OrElse Me.Disposing Then Return
        Me.Invoke(Sub()
                      TextBox_MainArea_MSR_Track1.Text = t1
                      TextBox_MainArea_MSR_Track2.Text = t2
                      TextBox_MainArea_MSR_Track3.Text = t3
                      TextBox_MainArea_MSR_Track4.Text = t4
                  End Sub)
    End Sub




    Private Sub Button_MainArea_MSR_CheckFeatures_Click(sender As Object, e As EventArgs) Handles Button_MainArea_MSR_CheckFeatures.Click
        Try
            Dim features As String = pos.GetMsrFeatures()
            UpdateResults(vbCrLf & DateTime.Now.ToString("HH:mm:ss") & " " & features)
        Catch ex As Exception
            VB.Log("MSR Check Features Error: ", LogLevel.Trace, ex)
            UpdateResults("MSR Check Features Error: " & ex.Message)
        End Try
    End Sub





    Private Sub TextBox_MainArea_MSR_Track1_TextChanged(sender As Object, e As EventArgs) Handles TextBox_MainArea_MSR_Track1.TextChanged

    End Sub

    Private Sub TextBox_MainArea_MSR_Track2_TextChanged(sender As Object, e As EventArgs) Handles TextBox_MainArea_MSR_Track2.TextChanged

    End Sub

    Private Sub TextBox_MainArea_MSR_Track3_TextChanged(sender As Object, e As EventArgs) Handles TextBox_MainArea_MSR_Track3.TextChanged

    End Sub

    Private Sub TextBox_MainArea_MSR_Track4_TextChanged(sender As Object, e As EventArgs) Handles TextBox_MainArea_MSR_Track4.TextChanged

    End Sub

    Private Sub CheckBox_MainArea_MSR_SendSentinels_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MainArea_MSR_SendSentinels.CheckedChanged
        ' V3
        ' Only proceed if the user actually clicked it (prevents code-driven loops)
        If Not CheckBox_MainArea_MSR_SendSentinels.Focused Then Return

        Try
            pos.SetMsrSentinels(CheckBox_MainArea_MSR_SendSentinels.Checked)
        Catch
            ' If the manager threw an error, uncheck the box
            RemoveHandler CheckBox_MainArea_MSR_SendSentinels.CheckedChanged, AddressOf CheckBox_MainArea_MSR_SendSentinels_CheckedChanged
            CheckBox_MainArea_MSR_SendSentinels.Checked = False
            AddHandler CheckBox_MainArea_MSR_SendSentinels.CheckedChanged, AddressOf CheckBox_MainArea_MSR_SendSentinels_CheckedChanged
        End Try
    End Sub


    Public Sub SyncSentinelsCheckbox(enabled As Boolean)
        ' We MUST use Invoke because the WebSocket runs on a background thread
        If Me.InvokeRequired Then
            Me.Invoke(Sub() SyncSentinelsCheckbox(enabled))
            Return
        End If

        ' Temporarily remove handler to prevent the CheckedChanged event from 
        ' trying to send the command back to the manager (preventing a loop)
        RemoveHandler CheckBox_MainArea_MSR_SendSentinels.CheckedChanged, AddressOf CheckBox_MainArea_MSR_SendSentinels_CheckedChanged

        CheckBox_MainArea_MSR_SendSentinels.Checked = enabled

        ' Re-attach the handler
        AddHandler CheckBox_MainArea_MSR_SendSentinels.CheckedChanged, AddressOf CheckBox_MainArea_MSR_SendSentinels_CheckedChanged
    End Sub



    Private Sub Button_MainArea_MSR_ClearTracks_Click(sender As Object, e As EventArgs) Handles Button_MainArea_MSR_ClearTracks.Click
        clear_AllMSRTracks()
    End Sub


    Private Sub resetAllUIFields()
        VB.Log("Resetting all UI Fields...", LogLevel.Debug)
        clear_AllMSRTracks()
        VB.Log("UI Fields Reset successfully", LogLevel.Debug)
    End Sub


    Public Sub clear_AllMSRTracks()
        If Me.InvokeRequired Then
            Me.Invoke(Sub() clear_AllMSRTracks())
            Return
        End If

        ' 1. Clear the physical TextBoxes on the WinForm
        TextBox_MainArea_MSR_Track1.Clear()
        TextBox_MainArea_MSR_Track2.Clear()
        TextBox_MainArea_MSR_Track3.Clear()
        TextBox_MainArea_MSR_Track4.Clear()
        'UpdateResults("MSR TRACKS CLEARED")

        ' 2. Tell the manager to tell the Web App to clear its tracks
        pos.ClearMsrTrackBuffers()
        VB.Log("MSR Tracks and buffers cleared successfully", LogLevel.Debug)
    End Sub




    ' Form Closing 
    Private Sub FormMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'Dim result As DialogResult
        'If wsServer.IsRunning Then
        '    result = MessageBox.Show("WebSocket Server is still running." & vbCrLf & "Kill server and Quit " & thisApp_Name & "?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        'Else
        '    result = MessageBox.Show("Quit " & thisApp_Name & "?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        'End If

        'If result = DialogResult.No Then
        '    e.Cancel = True
        'End If
    End Sub


End Class












'' NOTES

'On the opos module app 
'Using proper MSR user 
';ABCDEFGHIJKLMNO=;123456=;1234=
'doesnt handle it properly 
'add extra ui fields To show the filtered data so its clear 



' MSR ENCODING 
' ISO 7813 pattern: %[Format Code][Account Number]^[Name]^[Expiry/Service Code][Discretionary Data]?


';ABCDEFGHIJKLMNO=;123456=;1234=

' Paste the following string in to track 1, to simulate signing in as cashier code "30"
';              =;30    =;    =


'Replace 30 with the assistant code that you want to use And press the scan button.
'The following example Is For assistant code 1, padding Is maintained. 
';              =;1     =;    =




