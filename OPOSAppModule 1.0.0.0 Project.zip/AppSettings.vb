﻿

Imports System.IO
Imports Newtonsoft.Json


Public Class AppSettings

    ' Backing field (private)
    Private Shared ReadOnly _configPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appSettings.json")



    ' Public read-only accessor
    Public Shared ReadOnly Property ConfigPath As String
        Get
            Return _configPath
        End Get
    End Property



    ' Setting Properties
    Public Property WebSocketPort As Integer = 8081
    Public Property StartWebSocketOnLaunch As Boolean = False
    Public Property StartSilent As Boolean = False

    ' --- NEW: Logging Settings ---
    Public Property LogFileName As String = "EPOSCore"
    Public Property LogPath As String = ""
    Public Property LogFormat As String = "text"
    Public Property RetentionDays As Integer = 7
    Public Property MinimumLevel As LogLevel = LogLevel.Info ' Uses the Enum from your VB class




    Public Sub ResetSettingsToDefaults()
        ' Reset all properties to their initial values
        WebSocketPort = 8081
        StartWebSocketOnLaunch = False
        StartSilent = False
        LogFileName = "EPOSCore"
        LogFormat = "text"
        RetentionDays = 7
        MinimumLevel = LogLevel.Info
    End Sub



    '' Load settings from file
    'Public Sub LoadSettings_FromFile(Optional ByVal filePath As String = Nothing)
    '    Try
    '        ' Use the passed filePath if provided; otherwise, fall back to ConfigPath
    '        Dim pathToUse As String = If(String.IsNullOrEmpty(filePath), ConfigPath, filePath)

    '        ' If the file doesn't exist, save defaults to the default ConfigPath only
    '        If Not File.Exists(pathToUse) Then
    '            ' Only save defaults to ConfigPath, not to the override path
    '            If String.IsNullOrEmpty(filePath) Then
    '                SaveSettings_ToFile()
    '            End If
    '            Return
    '        End If

    '        ' Read and populate settings
    '        Dim json As String = File.ReadAllText(pathToUse)
    '        JsonConvert.PopulateObject(json, Me)

    '    Catch ex As Exception
    '        Debug.WriteLine("Error loading settings: " & ex.Message)
    '    End Try
    'End Sub




    '' 4. Detailed Save Function
    'Public Sub SaveSettings_ToFile()
    '    Try
    '        Dim dir = Path.GetDirectoryName(ConfigPath)
    '        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
    '        Dim json As String = JsonConvert.SerializeObject(Me, Formatting.Indented)
    '        File.WriteAllText(ConfigPath, json)
    '    Catch ex As Exception
    '        MessageBox.Show("Failed to save settings: " & ex.Message)
    '    End Try
    'End Sub


    Public Sub LoadSettings_FromFile(Optional ByVal filePath As String = Nothing)
        Try
            Dim pathToUse As String = If(String.IsNullOrEmpty(filePath), ConfigPath, filePath)

            If Not File.Exists(pathToUse) Then
                SaveSettings_ToFile()
                Return
            End If

            Dim json As String = File.ReadAllText(pathToUse)

            ' Detect if the JSON is missing new fields (outdated structure)
            ' If it's missing "LogFileName", it's definitely old.
            If Not json.Contains("LogFileName") Then
                VB.Log("Outdated config detected. Recreating with defaults.", LogLevel.Warn)
                ResetSettingsToDefaults()
                SaveSettings_ToFile()
                Return
            End If

            JsonConvert.PopulateObject(json, Me)

        Catch ex As Exception
            VB.Log("Error loading settings:", LogLevel.Trace, ex)
            Debug.WriteLine("Error loading settings: " & ex.Message)
        End Try
    End Sub



    Public Sub SaveSettings_ToFile()
        Try
            Dim dir = Path.GetDirectoryName(ConfigPath)
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Dim json As String = JsonConvert.SerializeObject(Me, Formatting.Indented)
            File.WriteAllText(ConfigPath, json)
        Catch ex As Exception
            VB.Log("Failed to save settings: ", LogLevel.Trace, ex)
            MessageBox.Show("Failed to save settings: " & ex.Message)
        End Try
    End Sub



End Class