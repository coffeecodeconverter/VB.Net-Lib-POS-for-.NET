﻿
Imports System.IO
Imports System.Diagnostics
Imports System.Threading.Tasks



Module Functions


    Public thisApp_Version As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
    Public thisApp_Name As String = "EPOS Core"
    Public thisApp_WebSocketTesterAppPath As String = Path.Combine(Application.StartupPath, "MiniWebApp", "index.html")
    Public thisApp_DevDebugMode As Boolean = False


    ' Visibily Hide Tab Heders at runtime
    Public Sub HideTabHeaders(ByRef tabControl As TabControl)
        tabControl.Appearance = TabAppearance.FlatButtons
        tabControl.ItemSize = New Size(0, 1)
        tabControl.SizeMode = TabSizeMode.Fixed
    End Sub



    Public Async Function OpenFolderAsync(path As String) As Task(Of Boolean)
        If String.IsNullOrWhiteSpace(path) Then Return False
        Return Await Task.Run(Function()
                                  Try
                                      Dim folderPath As String = path

                                      ' Determine whether a file was passed
                                      If File.Exists(path) Then
                                          folderPath = System.IO.Path.GetDirectoryName(path)

                                      ElseIf System.IO.Path.HasExtension(path) Then
                                          ' Handles file paths that may not exist yet
                                          folderPath = System.IO.Path.GetDirectoryName(path)
                                      End If

                                      ' Validate resulting folder path
                                      If String.IsNullOrWhiteSpace(folderPath) Then Return False

                                      If Not Directory.Exists(folderPath) Then
                                          Throw New DirectoryNotFoundException(
                                          $"The directory does not exist: {folderPath}")
                                      End If

                                      ' Open Explorer
                                      Process.Start(New ProcessStartInfo With {
                                      .FileName = "explorer.exe",
                                      .Arguments = folderPath,
                                      .UseShellExecute = True
                                  })

                                      Return True

                                  Catch ex As UnauthorizedAccessException
                                      Debug.WriteLine($"Access denied opening Explorer: {ex.Message}")
                                      Return False

                                  Catch ex As DirectoryNotFoundException
                                      Debug.WriteLine(ex.Message)
                                      Return False

                                  Catch ex As IOException
                                      Debug.WriteLine($"IO error opening Explorer: {ex.Message}")
                                      Return False

                                  Catch ex As Exception
                                      Debug.WriteLine($"Unexpected error opening Explorer: {ex.Message}")
                                      Return False
                                  End Try
                              End Function)
    End Function




    Public Async Function OpenFileAsync(filePath As String) As Task(Of Boolean)
        If String.IsNullOrWhiteSpace(filePath) Then Return False
        Return Await Task.Run(Function()
                                  Try
                                      ' Validate file exists
                                      If Not File.Exists(filePath) Then
                                          Throw New FileNotFoundException(
                                              $"The file does not exist: {filePath}", filePath)
                                      End If

                                      ' Open file with default associated application
                                      Process.Start(New ProcessStartInfo With {
                                          .FileName = filePath,
                                          .UseShellExecute = True
                                      })

                                      Return True

                                  Catch ex As UnauthorizedAccessException
                                      Debug.WriteLine($"Access denied opening file: {ex.Message}")
                                      Return False

                                  Catch ex As FileNotFoundException
                                      Debug.WriteLine(ex.Message)
                                      Return False

                                  Catch ex As IOException
                                      Debug.WriteLine($"IO error opening file: {ex.Message}")
                                      Return False

                                  Catch ex As Exception
                                      Debug.WriteLine($"Unexpected error opening file: {ex.Message}")
                                      Return False
                                  End Try
                              End Function)
    End Function



End Module
