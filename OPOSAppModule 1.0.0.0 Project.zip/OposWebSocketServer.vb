﻿

Imports System.Net
Imports System.Net.WebSockets
Imports System.Text
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports Microsoft.PointOfService

Public Class OposWebSocketServer
    Private _listener As HttpListener
    Private _opos As OposManager
    Private _clients As New List(Of WebSocket)
    Private _serverThread As Thread
    Private _port As Integer

    Public ReadOnly Property Port As Integer
        Get
            Return _port
        End Get
    End Property

    Public Property IsRunning As Boolean = False
    Public Property LastError As String = ""


    Public Sub New(manager As OposManager, port As Integer)
        _opos = manager
        _listener = New HttpListener()
        _port = port
        ' Allows connections from the local machine on the specified port
        _listener.Prefixes.Add($"http://127.0.0.1:{port}/")

        ' Hook into your existing OposManager event
        AddHandler _opos.OnMsrDataReceived, AddressOf BroadcastMsrData
        AddHandler _opos.OnMsrConfigChanged, AddressOf BroadcastMsrConfig
        AddHandler _opos.OnMsrSentinelsChanged, AddressOf BroadcastMsrSentinels
    End Sub


    Public Sub StartWebServer()
        Try
            _listener.Start()
            _serverThread = New Thread(AddressOf ListenLoop)
            _serverThread.IsBackground = True
            _serverThread.Start()

            IsRunning = True
            ' We can't use RaiseEvent here easily because we are likely on a background thread,
            ' but the Form can check this property.
        Catch ex As HttpListenerException When ex.ErrorCode = 5
            IsRunning = False
            LastError = "Access Denied: Run as Admin or reserve the URL via netsh."
        Catch ex As Exception
            IsRunning = False
            LastError = "Server failed to start: " & ex.Message
        End Try
    End Sub

    Private Async Sub ListenLoop()
        While _listener.IsListening
            Try
                ' Wait for an incoming HTTP request
                Dim context As HttpListenerContext = Await _listener.GetContextAsync()

                If context.Request.IsWebSocketRequest Then
                    ' Accept the WebSocket handshake
                    Dim wsContext As HttpListenerWebSocketContext = Await context.AcceptWebSocketAsync(subProtocol:=Nothing)
                    Dim ws As WebSocket = wsContext.WebSocket

                    ' --- LOG THE CONNECTION HERE ---
                    Dim mainForm = TryCast(Application.OpenForms("FormMain"), FormMain)
                    mainForm?.Invoke(Sub()
                                         mainForm.UpdateResults($"[WS] Web App Connected (IP: {context.Request.RemoteEndPoint})")
                                     End Sub)

                    SyncLock _clients
                        _clients.Add(ws)
                    End SyncLock

                    ' Run the client handler in a separate task
                    Task.Run(Function() HandleClient(ws))
                Else
                    ' If it's a normal browser request, reject it
                    context.Response.StatusCode = 400
                    context.Response.Close()
                End If
            Catch ex As Exception
                ' Log or handle listener exceptions here
            End Try
        End While
    End Sub


    Public Async Sub StopWebServer() ' Brackets used because Stop is a reserved keyword in VB
        Try
            VB.Log("Stop WebSocket Server...", LogLevel.Info)

            IsRunning = False

            ' 1. Close all active client connections
            Dim clientsToClose As List(Of WebSocket)
            SyncLock _clients
                clientsToClose = _clients.ToList()
                _clients.Clear()
            End SyncLock

            For Each client In clientsToClose
                If client.State = WebSocketState.Open Then
                    Try
                        ' Notify client we are closing
                        Await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server Shutting Down", CancellationToken.None)
                        VB.Log("WebSocket client cleared successfully", LogLevel.Debug)
                    Catch
                        ' Ignore errors during mass disconnect
                    End Try
                End If
            Next

            ' 2. Stop the listener
            VB.Log("Stopping WebSocket Listener...", LogLevel.Info)
            If _listener IsNot Nothing AndAlso _listener.IsListening Then
                _listener.Stop()
                _listener.Close()
                VB.Log("WebSocket Server and listener stopped successfully", LogLevel.Info)
            End If

            ' 3. Re-initialize listener for next Start call
            _listener = New HttpListener()
            VB.Log("WebSocket Listener re-initialized", LogLevel.Debug)

            LastError = ""
        Catch ex As Exception
            LastError = "Error attempting to stop WebSocket Server: " & ex.Message
            VB.Log("Error attempting to stop WebSocket Server", LogLevel.Trace, ex)
        End Try
    End Sub





    ' Add this to OposWebSocketServer class
    'Public Async Sub BroadcastStatus(statusType As String, value As Object)
    Public Async Sub BroadcastStatus(category As String, statusType As String, value As Object)
        ' Create a simple JSON object: { "type": "STATUS", "key": "IsOpened", "value": true }
        'Dim json As String = $"{{ ""type"": ""STATUS"", ""key"": ""{statusType}"", ""value"": {value.ToString().ToLower()} }}"
        ' Dim json As String = $"{{ ""type"": ""STATUS"", ""category"": ""{category}"", ""key"": ""{statusType}"", ""value"": {value.ToString().ToLower()} }}"

        ' Determine if we need quotes (strings need quotes, booleans/numbers don't)
        Dim formattedValue As String
        If TypeOf value Is String Then
            formattedValue = $"""{value}""" ' Wrap in double quotes
        Else
            formattedValue = value.ToString().ToLower() ' true/false
        End If

        Dim json As String = $"{{ ""type"": ""STATUS"", ""category"": ""{category}"", ""key"": ""{statusType}"", ""value"": {formattedValue} }}"

        Dim bytes As Byte() = Encoding.UTF8.GetBytes(json)
        Dim segment As New ArraySegment(Of Byte)(bytes)

        Dim clientsCopy As List(Of WebSocket)
        SyncLock _clients
            clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
        End SyncLock

        For Each client In clientsCopy
            Try
                Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
            Catch
                ' Handle dropped connections
            End Try
        Next
    End Sub


    Private Async Function HandleClient(ws As WebSocket) As Task
        'Dim buffer(4096) As Byte

        'Try
        '    While ws.State = WebSocketState.Open
        '        Dim result As WebSocketReceiveResult = Await ws.ReceiveAsync(New ArraySegment(Of Byte)(buffer), CancellationToken.None)

        '        If result.MessageType = WebSocketMessageType.Text Then
        '            Dim msg As String = Encoding.UTF8.GetString(buffer, 0, result.Count)
        '            ProcessIncomingMessage(msg)
        '        ElseIf result.MessageType = WebSocketMessageType.Close Then
        '            SyncLock _clients
        '                _clients.Remove(ws)
        '            End SyncLock
        '            Await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed by client", CancellationToken.None)
        '        End If
        '    End While
        'Catch ex As Exception
        '    SyncLock _clients
        '        _clients.Remove(ws)
        '    End SyncLock
        'End Try


        Dim buffer(4096) As Byte

        Try
            While ws.State = WebSocketState.Open
                Dim result As WebSocketReceiveResult = Await ws.ReceiveAsync(New ArraySegment(Of Byte)(buffer), CancellationToken.None)

                If result.MessageType = WebSocketMessageType.Text Then
                    Dim msg As String = Encoding.UTF8.GetString(buffer, 0, result.Count)
                    ProcessIncomingMessage(msg)
                ElseIf result.MessageType = WebSocketMessageType.Close Then
                    Exit While ' Jump to Finally
                End If
            End While
        Catch ex As Exception
            ' Connection lost/error
        Finally
            ' --- RECORD DISCONNECT ---
            SyncLock _clients
                _clients.Remove(ws)
            End SyncLock

            Dim mainForm = TryCast(Application.OpenForms(0), FormMain)
            mainForm?.Invoke(Sub() mainForm.UpdateResults("[WS] Web App Disconnected"))

            ' Clean up socket if still semi-open
            If ws.State = WebSocketState.Open OrElse ws.State = WebSocketState.CloseReceived Then
                ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed", CancellationToken.None)
            End If

            ' Final cleanup
            ws.Dispose()
            ws = Nothing
        End Try
    End Function





    Public Sub UpdateManager(newManager As OposManager)
        ' Detach from old manager event to prevent memory leaks
        If _opos IsNot Nothing Then
            RemoveHandler _opos.OnMsrDataReceived, AddressOf BroadcastMsrData
        End If

        ' Assign the new manager
        _opos = newManager

        ' Attach to the new manager's event
        AddHandler _opos.OnMsrDataReceived, AddressOf BroadcastMsrData
    End Sub




    'Private Sub ProcessIncomingMessage(msg As String)
    '    '' V3
    '    '' We need to ensure these run on the UI thread so the Simulator window can show
    '    '' Assuming 'formMain' is your main form instance. 
    '    '' If this class doesn't have a reference to the form, you may need to pass one in.
    '    'Application.OpenForms(0).Invoke(Sub()
    '    '                                    Dim parts = msg.Split(":"c)
    '    '                                    Dim command = parts(0).ToUpper().Trim()

    '    '                                    Select Case command
    '    '                                        Case "OPEN_DEVICE"
    '    '                                            ' Use the name from the web app, or default to OPOSDRW1
    '    '                                            Dim ldn As String = If(parts.Length > 1, parts(1), "OPOSDRW1")
    '    '                                            _opos.OpenDeviceByLogicalName(ldn, DeviceType.CashDrawer)

    '    '                                        Case "CLAIM_DEVICE"
    '    '                                            _opos.ClaimDevice(1000)

    '    '                                        Case "ENABLE_DEVICE"
    '    '                                            _opos.SetEnabled(True)

    '    '                                        Case "DISABLE_DEVICE"
    '    '                                            _opos.SetEnabled(False)

    '    '                                        Case "OPEN_DRAWER"
    '    '                                            _opos.OpenCashDrawer()

    '    '                                        Case "RELEASE_DEVICE"
    '    '                                            _opos.ReleaseDevice()

    '    '                                        Case "CLOSE_DEVICE"
    '    '                                            _opos.CloseActiveDevice()
    '    '                                    End Select
    '    '                                End Sub)


    '    ' V4
    '    ' We need to ensure these run on the UI thread so the Simulator window can show
    '    ' Assuming 'formMain' is your main form instance. 
    '    ' If this class doesn't have a reference to the form, you may need to pass one in.
    '    Dim mainForm = TryCast(Application.OpenForms(0), FormMain)
    '    If mainForm Is Nothing Then Return

    '    mainForm.Invoke(Sub()
    '                        Dim parts = msg.Split(":"c)
    '                        Dim command = parts(0).ToUpper().Trim()

    '                        Select Case command
    '                            Case "OPEN_DEVICE"
    '                                ' Use the name from the web app, or default to OPOSDRW1
    '                                Dim ldn As String = If(parts.Length > 1, parts(1), "OPOSDRW1")
    '                                '_opos.OpenDeviceByLogicalName(ldn, DeviceType.CashDrawer)

    '                            Case "CLAIM_DEVICE"
    '                                '_opos.ClaimDevice(1000)

    '                            Case "ENABLE_DEVICE"
    '                               ' _opos.SetEnabled(True)

    '                            Case "DISABLE_DEVICE"
    '                                '_opos.SetEnabled(False)

    '                            Case "OPEN_DRAWER"
    '                                _opos.OpenCashDrawer()

    '                            Case "RELEASE_DEVICE"
    '                                '_opos.ReleaseDevice()

    '                            Case "CLOSE_DEVICE"
    '                                '_opos.CloseActiveDevice()

    '                            Case "RESET_APP"
    '                                ' Log the request to the UI before tearing down
    '                                mainForm.UpdateResults("Web Request: Full App Reset Triggered.")
    '                                ' Call the re-initialization method
    '                                mainForm.InitialiseMainApp()
    '                        End Select
    '                    End Sub)

    'End Sub



    Private Sub ProcessIncomingMessage(msg As String)
        Dim mainForm = TryCast(Application.OpenForms(0), FormMain)
        If mainForm Is Nothing Then Return

        mainForm.Invoke(Sub()
                            ' Split message (e.g., "CLAIM_DEVICE:CashDrawer" or "OPEN_DEVICE:OPOSDRW1:CashDrawer")
                            'Dim parts = msg.Split(":"c)
                            'Dim command = parts(0).ToUpper().Trim()

                            Debug.WriteLine("========== MESSAGE PARSE ==========")
                            Debug.WriteLine($"Raw message received: [{msg}]")

                            Dim parts = msg.Split(":"c)

                            Debug.WriteLine($"Split count: {parts.Length}")
                            For i As Integer = 0 To parts.Length - 1
                                Debug.WriteLine($"  parts({i}) = [{parts(i)}]")
                            Next

                            Dim command = parts(0).ToUpper().Trim()
                            Debug.WriteLine($"Parsed command: [{command}]")

                            ' Safely extract LDN and Category from parts
                            ' msg format: COMMAND:LDN:CATEGORY
                            Dim sentLDN As String = If(parts.Length > 1, parts(1).Trim(), "")
                            Dim sentCategory As String = If(parts.Length > 2, parts(2).Trim(), "")
                            Debug.WriteLine($"Sent Category: [{sentCategory}]")
                            Debug.WriteLine($"Sent LDN: [{sentLDN}]")

                            Debug.WriteLine("===================================")





                            ' Helper to get category from message, defaulting to CashDrawer for legacy support
                            Dim GetCategory = Function(index As Integer) As String
                                                  ' 1. If the message actually SPECIFIED a category (e.g. CLAIM_DEVICE:Msr), use it
                                                  If parts.Length > index Then
                                                      Return parts(index).Trim()
                                                  End If

                                                  ' 2. Otherwise, fall back to whatever tab the user is currently looking at
                                                  If mainForm.TabControl_Main.SelectedTab Is mainForm.TabPage_Main_MSR Then
                                                      Return DeviceType.Msr
                                                  Else
                                                      Return DeviceType.CashDrawer
                                                  End If
                                              End Function


                            Select Case command

                                Case "SWITCH_TAB"
                                    Dim targetCatStr = parts(1) ' "Msr" or "CashDrawer"
                                    mainForm.Invoke(Sub()
                                                        ' 1. Physically switch the tab
                                                        If targetCatStr = "Msr" Then
                                                            mainForm.TabControl_Main.SelectedTab = mainForm.TabPage_Main_MSR
                                                        Else
                                                            mainForm.TabControl_Main.SelectedTab = mainForm.TabPage_Main_CashDrawer
                                                        End If

                                                        ' 2. Pass the string to your refresh logic
                                                        mainForm.UpdateResults($"CATEGORY CHANGED TO: {targetCatStr}")
                                                        mainForm.UpdateComboBoxForCategory(targetCatStr)
                                                    End Sub)

                                Case "OPEN_DEVICE"
                                    'Dim ldn As String = If(parts.Length > 1, parts(1), "OPOSDRW1")
                                    'Dim category As String = GetCategory(2)
                                    '_opos.OpenDeviceByLogicalName(ldn, category)

                                    'Dim ldn As String
                                    'If parts.Length > 1 Then
                                    '    ldn = parts(1)
                                    'End If

                                    'If Not String.IsNullOrEmpty(ldn) Then
                                    '    Dim category As String = GetCategory(2)
                                    '    Debug.WriteLine("========== OPEN_DEVICE ==========")
                                    '    Debug.WriteLine($"LDN      = [{ldn}]")
                                    '    Debug.WriteLine($"Category = [{category}]")
                                    '    Debug.WriteLine("=================================")
                                    '    _opos.OpenDeviceByLogicalName(ldn, category)
                                    'Else
                                    '    mainForm.UpdateResults("Passed Logical Device Name (LDN) was empty or NULL - Failed to Open OPOS Device")
                                    'End If

                                    'If Not String.IsNullOrEmpty(sentLDN) Then
                                    '    ' We use the category sent from the web dropdown
                                    '    Debug.WriteLine($"[WS] Opening {sentLDN} as {sentCategory}")
                                    '    _opos.OpenDeviceByLogicalName(sentLDN, sentCategory)
                                    'Else
                                    '    mainForm.UpdateResults("Error: LDN was empty.")
                                    'End If

                                    If Not String.IsNullOrEmpty(sentLDN) Then
                                        ' --- Update the variables on the Form ---
                                        If sentCategory = DeviceType.Msr Then
                                            mainForm._lastSelectedMsrName = sentLDN
                                        ElseIf sentCategory = DeviceType.CashDrawer Then
                                            mainForm._lastSelectedDrawerName = sentLDN
                                        End If

                                        ' Now open the device via the manager
                                        _opos.OpenDeviceByLogicalName(sentLDN, sentCategory)
                                    Else
                                        mainForm.UpdateResults("Error: LDN was empty.")
                                    End If


                                'Case "CLAIM_DEVICE"
                                '    _opos.ClaimDevice(GetCategory(1), 1000)

                                'Case "ENABLE_DEVICE"
                                '    _opos.SetEnabled(GetCategory(1), True)

                                'Case "DISABLE_DEVICE"
                                '    _opos.SetEnabled(GetCategory(1), False)

                                'Case "RELEASE_DEVICE"
                                '    _opos.ReleaseDevice(GetCategory(1))

                                'Case "CLOSE_DEVICE"
                                '    _opos.CloseDeviceByType(GetCategory(1))

                                Case "CLAIM_DEVICE", "ENABLE_DEVICE", "DISABLE_DEVICE", "RELEASE_DEVICE", "CLOSE_DEVICE"
                                    ' These commands usually just need the Category to know which 
                                    ' internal OPOS object to trigger
                                    If Not String.IsNullOrEmpty(sentCategory) Then
                                        Select Case command
                                            Case "CLAIM_DEVICE" : _opos.ClaimDevice(sentCategory, 1000)
                                            Case "ENABLE_DEVICE" : _opos.SetEnabled(sentCategory, True)
                                                '' msg: ENABLE_DEVICE:LDN:TYPE:KEEP_ARMED:SENTINELS
                                                'If parts.Length > 3 Then Boolean.TryParse(parts(3), _KeepMsrArmed)
                                                'If parts.Length > 4 Then Boolean.TryParse(parts(4), _MsrIncludeSentinels)

                                            Case "DISABLE_DEVICE" : _opos.SetEnabled(sentCategory, False)
                                            Case "RELEASE_DEVICE" : _opos.ReleaseDevice(sentCategory)
                                            Case "CLOSE_DEVICE" : _opos.CloseDeviceByType(sentCategory)
                                        End Select
                                    End If


                                Case "CLOSE_ALL_DEVICES"
                                    _opos.CloseAllDevices()
                                    BroadcastLog("CLOSED ALL OPOS DEVICES")


                                Case "KEEP_DATA_EVENTS_ENABLED" ' Or whatever your command string is
                                    ' Expected format from JS: KEEP_DATA_EVENTS_ENABLED:MyLdn:msr:true
                                    If parts.Length >= 4 Then
                                        Dim enabled As Boolean = False
                                        Boolean.TryParse(parts(3), enabled)
                                        If sentCategory.ToLower() = "msr" Then
                                            _opos.SetMsrDataEvent(enabled)
                                            mainForm.SyncKeepArmedCheckbox(enabled)
                                        End If
                                    End If

                                Case "OPEN_DRAWER"
                                    _opos.OpenCashDrawer()

                                Case "DRAWER_STATUS"
                                    _opos.QueryDrawerStatus()


                                Case "MSR_FEATURES"
                                    Dim features As String = _opos.GetMsrFeatures()
                                    mainForm.UpdateResults(features)
                                    BroadcastLog(features)

                                Case "MSR_SET_SENTINELS"
                                    Dim enabled As Boolean = False
                                    If parts.Length > 1 Then Boolean.TryParse(parts(1), enabled)
                                    _opos.SetMsrSentinels(enabled)
                                    mainForm.SyncSentinelsCheckbox(enabled)

                                Case "MSR_CLEAR_TRACKS"
                                    mainForm.clear_AllMSRTracks()
                                    BroadcastLog("MSR: All track data cleared locally and remotely.")



                                Case "GET_OPOS_STATUS"
                                    '' New Command: Send full state back to web client
                                    'Dim cat = GetCategory(1)
                                    'Dim state = _opos.GetDeviceState(cat)
                                    'BroadcastStatus(cat, state.Summary)

                                    ' 1. Identify which device type the web app is currently looking at
                                    ' Note: If your web app sends "GET_OPOS_STATUS:CashDrawer", use parts(1)
                                    Dim cat = GetCategory(1)

                                    ' 2. Get the actual state object from the manager
                                    Dim state = _opos.GetDeviceState(cat)
                                    mainForm.pos_OnStateChanged()
                                    ' 4. Also send the human-readable summary to the log
                                    mainForm.UpdateResults(("OPOS Status: " & state.Summary))
                                    BroadcastLog($"{cat} OPOS Status: {state.Summary}")

                                    '' 5. If it's a drawer, refresh the physical sensor too
                                    'If cat = DeviceType.CashDrawer Then
                                    '    _opos.QueryDrawerStatus()
                                    'End If


                                Case "APPLICATION_SHOW"
                                    mainForm.Application_Show()
                                    BroadcastLog("App: EPOS Core brought to foreground.")

                                Case "APPLICATION_HIDE"
                                    mainForm.Application_Hide()
                                    BroadcastLog("App: EPOS Core hidden.")



                                Case "APPLICATION_LOG_FOLDER"
                                    mainForm.OpenLogFolder()
                                    mainForm.UpdateResults("Web Request: Open Logs Folder.")

                                Case "APPLICATION_LOG_FILE"
                                    mainForm.OpenLogFile()
                                    mainForm.UpdateResults("Web Request: Open Log File.")


                                Case "CLEAR_RESULTS"
                                    mainForm.ClearResultsOnMainForm()

                                Case "RESET_APP"
                                    mainForm.UpdateResults("Web Request: Full App Reset Triggered.")
                                    mainForm.InitialiseMainApp()

                            End Select
                        End Sub)
    End Sub





    '' --- BROADCAST LOGIC (Push data to Web) ---
    '''''Public Async Sub BroadcastDrawerHardwareStatus(isOpen As Boolean)
    '''''    Dim statusText = If(isOpen, "OPEN", "CLOSED")
    '''''    Dim json = $"{{ ""type"": ""DRAWER_STATUS"", ""status"": ""{statusText}"" }}"

    '''''    Dim bytes = Encoding.UTF8.GetBytes(json)
    '''''    Dim segment As New ArraySegment(Of Byte)(bytes)

    '''''    Dim clientsCopy As List(Of WebSocket)
    '''''    SyncLock _clients
    '''''        clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
    '''''    End SyncLock

    '''''    For Each client In clientsCopy
    '''''        Try
    '''''            Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
    '''''        Catch
    '''''        End Try
    '''''    Next
    '''''End Sub


    '' V1
    'Private Async Sub BroadcastMsrData(t1 As String, t2 As String, t3 As String, t4 As String)
    '    ' Build a simple JSON string manually
    '    ' (For complex data, consider using Newtonsoft.Json)
    '    Dim json As String = $"{{ ""type"": ""MSR"", ""t1"": ""{t1}"", ""t2"": ""{t2}"", ""t3"": ""{t3}"" }}"
    '    Dim bytes As Byte() = Encoding.UTF8.GetBytes(json)
    '    Dim segment As New ArraySegment(Of Byte)(bytes)

    '    ' Send to all currently connected web clients
    '    Dim clientsCopy As List(Of WebSocket)
    '    SyncLock _clients
    '        clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
    '    End SyncLock

    '    For Each client In clientsCopy
    '        Try
    '            Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
    '        Catch
    '            ' Connection might have dropped
    '        End Try
    '    Next
    'End Sub


    'V2
    Private Async Sub BroadcastMsrData(t1 As String, t2 As String, t3 As String, t4 As String)
        ' 1. Use "MSR_DATA" to match the JS if/else block
        ' 2. Use "track1", "track2" etc. to match the JS data.track1 checks
        Dim json As String = "{" &
        """type"": ""MSR_DATA""," &
        """track1"": """ & t1 & """," &
        """track2"": """ & t2 & """," &
        """track3"": """ & t3 & """," &
        """track4"": """ & t4 & """" &
        "}"

        Dim bytes As Byte() = Encoding.UTF8.GetBytes(json)
        Dim segment As New ArraySegment(Of Byte)(bytes)

        ' Send to all currently connected web clients
        Dim clientsCopy As List(Of WebSocket)
        SyncLock _clients
            clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
        End SyncLock

        For Each client In clientsCopy
            Try
                Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
            Catch
                ' Connection might have dropped
            End Try
        Next
    End Sub


    ' New Sub in WebSocketServer to send the tick to the Web App
    Private Async Sub BroadcastMsrConfig(isArmed As Boolean)
        Dim json = $"{{ ""type"": ""MSR_CONFIG"", ""armed"": {isArmed.ToString().ToLower()} }}"
        Dim bytes = Encoding.UTF8.GetBytes(json)
        Dim segment As New ArraySegment(Of Byte)(bytes)

        ' 1. Get a thread-safe copy of the connected clients
        Dim clientsCopy As List(Of WebSocket)
        SyncLock _clients
            clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
        End SyncLock

        ' 2. Send the config update to every client
        For Each client In clientsCopy
            Try
                Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
            Catch
                ' If sending fails, the client likely disconnected
            End Try
        Next
    End Sub


    Private Async Sub BroadcastMsrSentinels(enabled As Boolean)
        Dim json = $"{{ ""type"": ""MSR_SENTINELS_CONFIG"", ""enabled"": {enabled.ToString().ToLower()} }}"
        Dim bytes = Encoding.UTF8.GetBytes(json)
        Dim segment As New ArraySegment(Of Byte)(bytes)

        Dim clientsCopy As List(Of WebSocket)
        SyncLock _clients
            clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
        End SyncLock

        For Each client In clientsCopy
            Try
                Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
            Catch
            End Try
        Next
    End Sub





    Public Async Sub BroadcastLog(message As String)
        Try
            ' 1. Prepare the JSON - Escape quotes and handle newlines for JS compatibility
            ' We use \n for newlines so the HTML log can handle them, or <br> if you prefer
            Dim cleanMsg = message.Replace(vbCrLf, "\n").Replace(vbLf, "\n").Replace("""", "\""")
            Dim json As String = $"{{ ""type"": ""LOG"", ""message"": ""{cleanMsg}"" }}"

            Dim bytes As Byte() = Encoding.UTF8.GetBytes(json)
            Dim segment As New ArraySegment(Of Byte)(bytes)

            ' 2. Get a thread-safe copy of active clients
            Dim clientsCopy As List(Of WebSocket)
            SyncLock _clients
                clientsCopy = _clients.Where(Function(c) c.State = WebSocketState.Open).ToList()
            End SyncLock

            ' 3. Send to all clients
            For Each client In clientsCopy
                Try
                    ' We use a Task.Run or simply Await to ensure we don't block the UI thread
                    Await client.SendAsync(segment, WebSocketMessageType.Text, True, CancellationToken.None)
                Catch ex As Exception
                    ' Likely a silent disconnect
                    Debug.WriteLine("WS Broadcast Error: " & ex.Message)
                End Try
            Next
        Catch ex As Exception
            Debug.WriteLine("Critical BroadcastLog Error: " & ex.Message)
        End Try
    End Sub


End Class