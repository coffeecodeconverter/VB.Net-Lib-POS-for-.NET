﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSettings))
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox_Settings_WebSocketServer_Port = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CheckBox_Settings_App_LaunchSilently = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch = New System.Windows.Forms.CheckBox()
        Me.Label_DeviceList_Title = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button_Settings_Save = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadConfigFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox_Settings_App_LogFileName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.NumericUpDown_Settings_App_RetentionDays = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.RadioButton_Settings_App_NDJSONFormat = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Settings_App_TextFormat = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ComboBox_Settings_App_LogLevel = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBox_Settings_App_LogFolder = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button_Settings_App_Defaults = New System.Windows.Forms.Button()
        Me.Button_Settings_App_ClearLogs = New System.Windows.Forms.Button()
        Me.Panel8.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.NumericUpDown_Settings_App_RetentionDays, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel8.Controls.Add(Me.TextBox_Settings_WebSocketServer_Port)
        Me.Panel8.Controls.Add(Me.Label6)
        Me.Panel8.Location = New System.Drawing.Point(469, 24)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(85, 24)
        Me.Panel8.TabIndex = 6
        '
        'TextBox_Settings_WebSocketServer_Port
        '
        Me.TextBox_Settings_WebSocketServer_Port.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Settings_WebSocketServer_Port.Location = New System.Drawing.Point(39, 2)
        Me.TextBox_Settings_WebSocketServer_Port.Name = "TextBox_Settings_WebSocketServer_Port"
        Me.TextBox_Settings_WebSocketServer_Port.Size = New System.Drawing.Size(43, 20)
        Me.TextBox_Settings_WebSocketServer_Port.TabIndex = 1
        Me.TextBox_Settings_WebSocketServer_Port.Text = "8081"
        Me.TextBox_Settings_WebSocketServer_Port.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Port:"
        '
        'CheckBox_Settings_App_LaunchSilently
        '
        Me.CheckBox_Settings_App_LaunchSilently.AutoSize = True
        Me.CheckBox_Settings_App_LaunchSilently.Location = New System.Drawing.Point(11, 32)
        Me.CheckBox_Settings_App_LaunchSilently.Name = "CheckBox_Settings_App_LaunchSilently"
        Me.CheckBox_Settings_App_LaunchSilently.Size = New System.Drawing.Size(98, 17)
        Me.CheckBox_Settings_App_LaunchSilently.TabIndex = 7
        Me.CheckBox_Settings_App_LaunchSilently.Text = "Launch Silently"
        Me.CheckBox_Settings_App_LaunchSilently.UseVisualStyleBackColor = True
        '
        'CheckBox_Settings_WebSocketServer_StartOnLaunch
        '
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.AutoSize = True
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.Location = New System.Drawing.Point(14, 32)
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.Name = "CheckBox_Settings_WebSocketServer_StartOnLaunch"
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.Size = New System.Drawing.Size(196, 17)
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.TabIndex = 8
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.Text = "Start WebSocket Server on Launch"
        Me.CheckBox_Settings_WebSocketServer_StartOnLaunch.UseVisualStyleBackColor = True
        '
        'Label_DeviceList_Title
        '
        Me.Label_DeviceList_Title.AutoSize = True
        Me.Label_DeviceList_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DeviceList_Title.Location = New System.Drawing.Point(3, 4)
        Me.Label_DeviceList_Title.Name = "Label_DeviceList_Title"
        Me.Label_DeviceList_Title.Size = New System.Drawing.Size(70, 13)
        Me.Label_DeviceList_Title.TabIndex = 9
        Me.Label_DeviceList_Title.Text = "Application"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "WebSocket Server"
        '
        'Button_Settings_Save
        '
        Me.Button_Settings_Save.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Settings_Save.Location = New System.Drawing.Point(506, 379)
        Me.Button_Settings_Save.Name = "Button_Settings_Save"
        Me.Button_Settings_Save.Size = New System.Drawing.Size(79, 23)
        Me.Button_Settings_Save.TabIndex = 11
        Me.Button_Settings_Save.Text = "Save"
        Me.Button_Settings_Save.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(421, 379)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(79, 23)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(597, 29)
        Me.Panel1.TabIndex = 13
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(597, 29)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadConfigFileToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 25)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LoadConfigFileToolStripMenuItem
        '
        Me.LoadConfigFileToolStripMenuItem.Name = "LoadConfigFileToolStripMenuItem"
        Me.LoadConfigFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LoadConfigFileToolStripMenuItem.Text = "Load Config File"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Panel8)
        Me.Panel2.Controls.Add(Me.CheckBox_Settings_WebSocketServer_StartOnLaunch)
        Me.Panel2.Location = New System.Drawing.Point(12, 249)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(573, 102)
        Me.Panel2.TabIndex = 14
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.Controls.Add(Me.TextBox_Settings_App_LogFileName)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Location = New System.Drawing.Point(6, 81)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(554, 24)
        Me.Panel3.TabIndex = 11
        '
        'TextBox_Settings_App_LogFileName
        '
        Me.TextBox_Settings_App_LogFileName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Settings_App_LogFileName.Location = New System.Drawing.Point(100, 2)
        Me.TextBox_Settings_App_LogFileName.Name = "TextBox_Settings_App_LogFileName"
        Me.TextBox_Settings_App_LogFileName.Size = New System.Drawing.Size(451, 20)
        Me.TextBox_Settings_App_LogFileName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Log File Name"
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.Controls.Add(Me.Button_Settings_App_ClearLogs)
        Me.Panel4.Controls.Add(Me.Button_Settings_App_Defaults)
        Me.Panel4.Controls.Add(Me.Panel9)
        Me.Panel4.Controls.Add(Me.Panel7)
        Me.Panel4.Controls.Add(Me.Panel6)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Label_DeviceList_Title)
        Me.Panel4.Controls.Add(Me.Panel3)
        Me.Panel4.Controls.Add(Me.CheckBox_Settings_App_LaunchSilently)
        Me.Panel4.Location = New System.Drawing.Point(12, 40)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(573, 203)
        Me.Panel4.TabIndex = 15
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.NumericUpDown_Settings_App_RetentionDays)
        Me.Panel9.Controls.Add(Me.Label5)
        Me.Panel9.Location = New System.Drawing.Point(6, 129)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(274, 24)
        Me.Panel9.TabIndex = 15
        '
        'NumericUpDown_Settings_App_RetentionDays
        '
        Me.NumericUpDown_Settings_App_RetentionDays.Location = New System.Drawing.Point(100, 2)
        Me.NumericUpDown_Settings_App_RetentionDays.Name = "NumericUpDown_Settings_App_RetentionDays"
        Me.NumericUpDown_Settings_App_RetentionDays.Size = New System.Drawing.Size(174, 20)
        Me.NumericUpDown_Settings_App_RetentionDays.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 4)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Retention Days"
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.RadioButton_Settings_App_NDJSONFormat)
        Me.Panel7.Controls.Add(Me.RadioButton_Settings_App_TextFormat)
        Me.Panel7.Location = New System.Drawing.Point(305, 105)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(255, 24)
        Me.Panel7.TabIndex = 14
        '
        'RadioButton_Settings_App_NDJSONFormat
        '
        Me.RadioButton_Settings_App_NDJSONFormat.AutoSize = True
        Me.RadioButton_Settings_App_NDJSONFormat.Location = New System.Drawing.Point(102, 4)
        Me.RadioButton_Settings_App_NDJSONFormat.Name = "RadioButton_Settings_App_NDJSONFormat"
        Me.RadioButton_Settings_App_NDJSONFormat.Size = New System.Drawing.Size(104, 17)
        Me.RadioButton_Settings_App_NDJSONFormat.TabIndex = 16
        Me.RadioButton_Settings_App_NDJSONFormat.TabStop = True
        Me.RadioButton_Settings_App_NDJSONFormat.Text = "NDJSON Format"
        Me.RadioButton_Settings_App_NDJSONFormat.UseVisualStyleBackColor = True
        '
        'RadioButton_Settings_App_TextFormat
        '
        Me.RadioButton_Settings_App_TextFormat.AutoSize = True
        Me.RadioButton_Settings_App_TextFormat.Location = New System.Drawing.Point(3, 3)
        Me.RadioButton_Settings_App_TextFormat.Name = "RadioButton_Settings_App_TextFormat"
        Me.RadioButton_Settings_App_TextFormat.Size = New System.Drawing.Size(81, 17)
        Me.RadioButton_Settings_App_TextFormat.TabIndex = 15
        Me.RadioButton_Settings_App_TextFormat.TabStop = True
        Me.RadioButton_Settings_App_TextFormat.Text = "Text Format"
        Me.RadioButton_Settings_App_TextFormat.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.ComboBox_Settings_App_LogLevel)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Location = New System.Drawing.Point(6, 105)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(274, 24)
        Me.Panel6.TabIndex = 13
        '
        'ComboBox_Settings_App_LogLevel
        '
        Me.ComboBox_Settings_App_LogLevel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_Settings_App_LogLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Settings_App_LogLevel.FormattingEnabled = True
        Me.ComboBox_Settings_App_LogLevel.Items.AddRange(New Object() {"Trace", "Debug", "Info", "Warn", "Err", "Fatal"})
        Me.ComboBox_Settings_App_LogLevel.Location = New System.Drawing.Point(100, 1)
        Me.ComboBox_Settings_App_LogLevel.Name = "ComboBox_Settings_App_LogLevel"
        Me.ComboBox_Settings_App_LogLevel.Size = New System.Drawing.Size(171, 21)
        Me.ComboBox_Settings_App_LogLevel.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 4)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Log Level"
        '
        'Panel5
        '
        Me.Panel5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel5.Controls.Add(Me.TextBox_Settings_App_LogFolder)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Location = New System.Drawing.Point(6, 56)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(554, 24)
        Me.Panel5.TabIndex = 12
        Me.Panel5.Visible = False
        '
        'TextBox_Settings_App_LogFolder
        '
        Me.TextBox_Settings_App_LogFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_Settings_App_LogFolder.Location = New System.Drawing.Point(100, 2)
        Me.TextBox_Settings_App_LogFolder.Name = "TextBox_Settings_App_LogFolder"
        Me.TextBox_Settings_App_LogFolder.Size = New System.Drawing.Size(451, 20)
        Me.TextBox_Settings_App_LogFolder.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Log Folder:"
        '
        'Button_Settings_App_Defaults
        '
        Me.Button_Settings_App_Defaults.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Settings_App_Defaults.Location = New System.Drawing.Point(491, 4)
        Me.Button_Settings_App_Defaults.Name = "Button_Settings_App_Defaults"
        Me.Button_Settings_App_Defaults.Size = New System.Drawing.Size(79, 23)
        Me.Button_Settings_App_Defaults.TabIndex = 16
        Me.Button_Settings_App_Defaults.Text = "Defaults"
        Me.Button_Settings_App_Defaults.UseVisualStyleBackColor = True
        '
        'Button_Settings_App_ClearLogs
        '
        Me.Button_Settings_App_ClearLogs.Location = New System.Drawing.Point(304, 130)
        Me.Button_Settings_App_ClearLogs.Name = "Button_Settings_App_ClearLogs"
        Me.Button_Settings_App_ClearLogs.Size = New System.Drawing.Size(79, 23)
        Me.Button_Settings_App_ClearLogs.TabIndex = 17
        Me.Button_Settings_App_ClearLogs.Text = "Clear Logs"
        Me.Button_Settings_App_ClearLogs.UseVisualStyleBackColor = True
        '
        'FormSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(597, 414)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button_Settings_Save)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimizeBox = False
        Me.Name = "FormSettings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Settings - EPOS Core"
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.NumericUpDown_Settings_App_RetentionDays, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel8 As Panel
    Friend WithEvents TextBox_Settings_WebSocketServer_Port As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents CheckBox_Settings_App_LaunchSilently As CheckBox
    Friend WithEvents CheckBox_Settings_WebSocketServer_StartOnLaunch As CheckBox
    Friend WithEvents Label_DeviceList_Title As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button_Settings_Save As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoadConfigFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBox_Settings_App_LogFileName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ComboBox_Settings_App_LogLevel As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBox_Settings_App_LogFolder As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents RadioButton_Settings_App_NDJSONFormat As RadioButton
    Friend WithEvents RadioButton_Settings_App_TextFormat As RadioButton
    Friend WithEvents NumericUpDown_Settings_App_RetentionDays As NumericUpDown
    Friend WithEvents Button_Settings_App_Defaults As Button
    Friend WithEvents Button_Settings_App_ClearLogs As Button
End Class
