﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.FlowLayoutPanel_DeviceList = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_DeviceList_CashDrawer = New System.Windows.Forms.Button()
        Me.Button_DeviceList_MSR = New System.Windows.Forms.Button()
        Me.Button_DeviceList_Dallas = New System.Windows.Forms.Button()
        Me.Panel_DeviceList_Wrap = New System.Windows.Forms.Panel()
        Me.Label_DeviceList_Title = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button_WebSocketServer_Test = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TextBox_WebSocketServer_Port = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button_WebSocketServer_Stop = New System.Windows.Forms.Button()
        Me.Button_WebSocketServer_Start = New System.Windows.Forms.Button()
        Me.MenuStrip_Main = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenApplicationFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetUIFieldsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideApplicationToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.LogsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ConfigFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl_Main = New System.Windows.Forms.TabControl()
        Me.TabPage_Main_CashDrawer = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TextBox_MainArea_CashDrawer_DrawerState = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label_MainTitle_CashDrawer = New System.Windows.Forms.Label()
        Me.Button_MainArea_CashDrawer_GetDrawerState = New System.Windows.Forms.Button()
        Me.Button_MainArea_CashDrawer_OpenDrawer = New System.Windows.Forms.Button()
        Me.TabPage_Main_MSR = New System.Windows.Forms.TabPage()
        Me.Button_MainArea_MSR_ClearTracks = New System.Windows.Forms.Button()
        Me.CheckBox_MainArea_MSR_SendSentinels = New System.Windows.Forms.CheckBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TextBox_MainArea_MSR_Track4 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox_MainArea_MSR_Track3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox_MainArea_MSR_Track2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_MainArea_MSR_Track1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button_MainArea_MSR_CheckFeatures = New System.Windows.Forms.Button()
        Me.Label_MainTitle_MSR = New System.Windows.Forms.Label()
        Me.TabPage_Main_Dallas = New System.Windows.Forms.TabPage()
        Me.Label_MainTitle_Dallas = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel_Toolbar_TabControlMain = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_OPOSToolbar_Open = New System.Windows.Forms.Button()
        Me.Button_OPOSToolbar_Claim = New System.Windows.Forms.Button()
        Me.CheckBox_OPOSToolbar_DeviceEnabled = New System.Windows.Forms.CheckBox()
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled = New System.Windows.Forms.CheckBox()
        Me.Button_OPOSToolbar_Release = New System.Windows.Forms.Button()
        Me.Button_OPOSToolbar_Close = New System.Windows.Forms.Button()
        Me.Button_OPOSToolbar_OPOSStatus = New System.Windows.Forms.Button()
        Me.Button_OPOSToolbar_ClearResults = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_OPOSStatusBar = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label_OPOSStatus_DeviceName = New System.Windows.Forms.Label()
        Me.Label_OPOSStatus_OpenState = New System.Windows.Forms.Label()
        Me.Label_OPOSStatus_ClaimState = New System.Windows.Forms.Label()
        Me.Label_OPOSStatus_EnableState = New System.Windows.Forms.Label()
        Me.Label_OPOSStatus_Summary = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox_Results = New System.Windows.Forms.TextBox()
        Me.Label_ResultsTitle = New System.Windows.Forms.Label()
        Me.ComboBox_Devices = New System.Windows.Forms.ComboBox()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label_WebSocketServer_Status = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.NotifyIcon_SystemTray_MainApp = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenuStrip_SystemTray_MainApp = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ShowApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppSettingsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ResetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button_OPOSToolbar_CloseAll = New System.Windows.Forms.Button()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.FlowLayoutPanel_DeviceList.SuspendLayout()
        Me.Panel_DeviceList_Wrap.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.MenuStrip_Main.SuspendLayout()
        Me.TabControl_Main.SuspendLayout()
        Me.TabPage_Main_CashDrawer.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage_Main_MSR.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TabPage_Main_Dallas.SuspendLayout()
        Me.FlowLayoutPanel_Toolbar_TabControlMain.SuspendLayout()
        Me.FlowLayoutPanel_OPOSStatusBar.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.ContextMenuStrip_SystemTray_MainApp.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel_DeviceList
        '
        Me.FlowLayoutPanel_DeviceList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_DeviceList.AutoScroll = True
        Me.FlowLayoutPanel_DeviceList.Controls.Add(Me.Button_DeviceList_CashDrawer)
        Me.FlowLayoutPanel_DeviceList.Controls.Add(Me.Button_DeviceList_MSR)
        Me.FlowLayoutPanel_DeviceList.Controls.Add(Me.Button_DeviceList_Dallas)
        Me.FlowLayoutPanel_DeviceList.Location = New System.Drawing.Point(3, 30)
        Me.FlowLayoutPanel_DeviceList.Name = "FlowLayoutPanel_DeviceList"
        Me.FlowLayoutPanel_DeviceList.Size = New System.Drawing.Size(140, 293)
        Me.FlowLayoutPanel_DeviceList.TabIndex = 0
        '
        'Button_DeviceList_CashDrawer
        '
        Me.Button_DeviceList_CashDrawer.Location = New System.Drawing.Point(3, 3)
        Me.Button_DeviceList_CashDrawer.Name = "Button_DeviceList_CashDrawer"
        Me.Button_DeviceList_CashDrawer.Size = New System.Drawing.Size(115, 30)
        Me.Button_DeviceList_CashDrawer.TabIndex = 0
        Me.Button_DeviceList_CashDrawer.Text = "Cash Drawer"
        Me.Button_DeviceList_CashDrawer.UseVisualStyleBackColor = True
        '
        'Button_DeviceList_MSR
        '
        Me.Button_DeviceList_MSR.Location = New System.Drawing.Point(3, 39)
        Me.Button_DeviceList_MSR.Name = "Button_DeviceList_MSR"
        Me.Button_DeviceList_MSR.Size = New System.Drawing.Size(115, 30)
        Me.Button_DeviceList_MSR.TabIndex = 1
        Me.Button_DeviceList_MSR.Text = "MSR"
        Me.Button_DeviceList_MSR.UseVisualStyleBackColor = True
        '
        'Button_DeviceList_Dallas
        '
        Me.Button_DeviceList_Dallas.Location = New System.Drawing.Point(3, 75)
        Me.Button_DeviceList_Dallas.Name = "Button_DeviceList_Dallas"
        Me.Button_DeviceList_Dallas.Size = New System.Drawing.Size(115, 30)
        Me.Button_DeviceList_Dallas.TabIndex = 2
        Me.Button_DeviceList_Dallas.Text = "Dallas"
        Me.Button_DeviceList_Dallas.UseVisualStyleBackColor = True
        Me.Button_DeviceList_Dallas.Visible = False
        '
        'Panel_DeviceList_Wrap
        '
        Me.Panel_DeviceList_Wrap.Controls.Add(Me.Label_DeviceList_Title)
        Me.Panel_DeviceList_Wrap.Controls.Add(Me.FlowLayoutPanel_DeviceList)
        Me.Panel_DeviceList_Wrap.Location = New System.Drawing.Point(0, 30)
        Me.Panel_DeviceList_Wrap.Name = "Panel_DeviceList_Wrap"
        Me.Panel_DeviceList_Wrap.Size = New System.Drawing.Size(146, 327)
        Me.Panel_DeviceList_Wrap.TabIndex = 1
        '
        'Label_DeviceList_Title
        '
        Me.Label_DeviceList_Title.AutoSize = True
        Me.Label_DeviceList_Title.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_DeviceList_Title.Location = New System.Drawing.Point(9, 6)
        Me.Label_DeviceList_Title.Name = "Label_DeviceList_Title"
        Me.Label_DeviceList_Title.Size = New System.Drawing.Size(67, 13)
        Me.Label_DeviceList_Title.TabIndex = 1
        Me.Label_DeviceList_Title.Text = "Categories"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel2.Controls.Add(Me.Button_WebSocketServer_Test)
        Me.Panel2.Controls.Add(Me.Panel8)
        Me.Panel2.Controls.Add(Me.Button_WebSocketServer_Stop)
        Me.Panel2.Controls.Add(Me.Button_WebSocketServer_Start)
        Me.Panel2.Controls.Add(Me.MenuStrip_Main)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(834, 30)
        Me.Panel2.TabIndex = 2
        '
        'Button_WebSocketServer_Test
        '
        Me.Button_WebSocketServer_Test.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WebSocketServer_Test.Location = New System.Drawing.Point(667, 3)
        Me.Button_WebSocketServer_Test.Name = "Button_WebSocketServer_Test"
        Me.Button_WebSocketServer_Test.Size = New System.Drawing.Size(79, 23)
        Me.Button_WebSocketServer_Test.TabIndex = 11
        Me.Button_WebSocketServer_Test.Text = "Test Server"
        Me.Button_WebSocketServer_Test.UseVisualStyleBackColor = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.TextBox_WebSocketServer_Port)
        Me.Panel8.Controls.Add(Me.Label6)
        Me.Panel8.Location = New System.Drawing.Point(493, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(85, 24)
        Me.Panel8.TabIndex = 5
        '
        'TextBox_WebSocketServer_Port
        '
        Me.TextBox_WebSocketServer_Port.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_WebSocketServer_Port.Location = New System.Drawing.Point(39, 2)
        Me.TextBox_WebSocketServer_Port.Name = "TextBox_WebSocketServer_Port"
        Me.TextBox_WebSocketServer_Port.ReadOnly = True
        Me.TextBox_WebSocketServer_Port.Size = New System.Drawing.Size(43, 20)
        Me.TextBox_WebSocketServer_Port.TabIndex = 1
        Me.TextBox_WebSocketServer_Port.Text = "8081"
        Me.TextBox_WebSocketServer_Port.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Port:"
        '
        'Button_WebSocketServer_Stop
        '
        Me.Button_WebSocketServer_Stop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WebSocketServer_Stop.Location = New System.Drawing.Point(752, 3)
        Me.Button_WebSocketServer_Stop.Name = "Button_WebSocketServer_Stop"
        Me.Button_WebSocketServer_Stop.Size = New System.Drawing.Size(79, 23)
        Me.Button_WebSocketServer_Stop.TabIndex = 10
        Me.Button_WebSocketServer_Stop.Text = "Stop Server"
        Me.Button_WebSocketServer_Stop.UseVisualStyleBackColor = True
        '
        'Button_WebSocketServer_Start
        '
        Me.Button_WebSocketServer_Start.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WebSocketServer_Start.Location = New System.Drawing.Point(582, 3)
        Me.Button_WebSocketServer_Start.Name = "Button_WebSocketServer_Start"
        Me.Button_WebSocketServer_Start.Size = New System.Drawing.Size(79, 23)
        Me.Button_WebSocketServer_Start.TabIndex = 9
        Me.Button_WebSocketServer_Start.Text = "Start Server"
        Me.Button_WebSocketServer_Start.UseVisualStyleBackColor = True
        '
        'MenuStrip_Main
        '
        Me.MenuStrip_Main.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip_Main.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip_Main.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip_Main.Name = "MenuStrip_Main"
        Me.MenuStrip_Main.Size = New System.Drawing.Size(834, 30)
        Me.MenuStrip_Main.TabIndex = 0
        Me.MenuStrip_Main.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenApplicationFolderToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 26)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenApplicationFolderToolStripMenuItem
        '
        Me.OpenApplicationFolderToolStripMenuItem.Name = "OpenApplicationFolderToolStripMenuItem"
        Me.OpenApplicationFolderToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.OpenApplicationFolderToolStripMenuItem.Text = "Open Application Folder"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(200, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResetUIFieldsToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 26)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ResetUIFieldsToolStripMenuItem
        '
        Me.ResetUIFieldsToolStripMenuItem.Name = "ResetUIFieldsToolStripMenuItem"
        Me.ResetUIFieldsToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.ResetUIFieldsToolStripMenuItem.Text = "Reset UI Fields"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HideApplicationToolStripMenuItem1, Me.ToolStripSeparator3, Me.LogsToolStripMenuItem, Me.ToolStripSeparator2, Me.ConfigFileToolStripMenuItem, Me.AppSettingsToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 26)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'HideApplicationToolStripMenuItem1
        '
        Me.HideApplicationToolStripMenuItem1.Name = "HideApplicationToolStripMenuItem1"
        Me.HideApplicationToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.HideApplicationToolStripMenuItem1.Text = "Hide Application"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(177, 6)
        '
        'LogsToolStripMenuItem
        '
        Me.LogsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FolderToolStripMenuItem, Me.FileToolStripMenuItem1, Me.ToolStripSeparator4, Me.ClearToolStripMenuItem})
        Me.LogsToolStripMenuItem.Name = "LogsToolStripMenuItem"
        Me.LogsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.LogsToolStripMenuItem.Text = "Logs"
        '
        'FolderToolStripMenuItem
        '
        Me.FolderToolStripMenuItem.Name = "FolderToolStripMenuItem"
        Me.FolderToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FolderToolStripMenuItem.Text = "Folder"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(177, 6)
        '
        'ConfigFileToolStripMenuItem
        '
        Me.ConfigFileToolStripMenuItem.Name = "ConfigFileToolStripMenuItem"
        Me.ConfigFileToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ConfigFileToolStripMenuItem.Text = "Config File"
        Me.ConfigFileToolStripMenuItem.Visible = False
        '
        'AppSettingsToolStripMenuItem
        '
        Me.AppSettingsToolStripMenuItem.Name = "AppSettingsToolStripMenuItem"
        Me.AppSettingsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AppSettingsToolStripMenuItem.Text = "Settings"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 26)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'TabControl_Main
        '
        Me.TabControl_Main.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl_Main.Controls.Add(Me.TabPage_Main_CashDrawer)
        Me.TabControl_Main.Controls.Add(Me.TabPage_Main_MSR)
        Me.TabControl_Main.Controls.Add(Me.TabPage_Main_Dallas)
        Me.TabControl_Main.Location = New System.Drawing.Point(152, 129)
        Me.TabControl_Main.Name = "TabControl_Main"
        Me.TabControl_Main.SelectedIndex = 0
        Me.TabControl_Main.Size = New System.Drawing.Size(678, 232)
        Me.TabControl_Main.TabIndex = 3
        '
        'TabPage_Main_CashDrawer
        '
        Me.TabPage_Main_CashDrawer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage_Main_CashDrawer.Controls.Add(Me.Panel1)
        Me.TabPage_Main_CashDrawer.Controls.Add(Me.Label_MainTitle_CashDrawer)
        Me.TabPage_Main_CashDrawer.Controls.Add(Me.Button_MainArea_CashDrawer_GetDrawerState)
        Me.TabPage_Main_CashDrawer.Controls.Add(Me.Button_MainArea_CashDrawer_OpenDrawer)
        Me.TabPage_Main_CashDrawer.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Main_CashDrawer.Name = "TabPage_Main_CashDrawer"
        Me.TabPage_Main_CashDrawer.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Main_CashDrawer.Size = New System.Drawing.Size(670, 206)
        Me.TabPage_Main_CashDrawer.TabIndex = 0
        Me.TabPage_Main_CashDrawer.Text = "Cash Drawer"
        Me.TabPage_Main_CashDrawer.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBox_MainArea_CashDrawer_DrawerState)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(14, 79)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(296, 24)
        Me.Panel1.TabIndex = 4
        Me.Panel1.Visible = False
        '
        'TextBox_MainArea_CashDrawer_DrawerState
        '
        Me.TextBox_MainArea_CashDrawer_DrawerState.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_MainArea_CashDrawer_DrawerState.Location = New System.Drawing.Point(82, 2)
        Me.TextBox_MainArea_CashDrawer_DrawerState.Name = "TextBox_MainArea_CashDrawer_DrawerState"
        Me.TextBox_MainArea_CashDrawer_DrawerState.Size = New System.Drawing.Size(214, 20)
        Me.TextBox_MainArea_CashDrawer_DrawerState.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Drawer State:"
        '
        'Label_MainTitle_CashDrawer
        '
        Me.Label_MainTitle_CashDrawer.AutoSize = True
        Me.Label_MainTitle_CashDrawer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MainTitle_CashDrawer.Location = New System.Drawing.Point(11, 11)
        Me.Label_MainTitle_CashDrawer.Name = "Label_MainTitle_CashDrawer"
        Me.Label_MainTitle_CashDrawer.Size = New System.Drawing.Size(79, 13)
        Me.Label_MainTitle_CashDrawer.TabIndex = 3
        Me.Label_MainTitle_CashDrawer.Text = "Cash Drawer"
        '
        'Button_MainArea_CashDrawer_GetDrawerState
        '
        Me.Button_MainArea_CashDrawer_GetDrawerState.Location = New System.Drawing.Point(165, 38)
        Me.Button_MainArea_CashDrawer_GetDrawerState.Name = "Button_MainArea_CashDrawer_GetDrawerState"
        Me.Button_MainArea_CashDrawer_GetDrawerState.Size = New System.Drawing.Size(145, 30)
        Me.Button_MainArea_CashDrawer_GetDrawerState.TabIndex = 2
        Me.Button_MainArea_CashDrawer_GetDrawerState.Text = "Get Drawer State"
        Me.Button_MainArea_CashDrawer_GetDrawerState.UseVisualStyleBackColor = True
        '
        'Button_MainArea_CashDrawer_OpenDrawer
        '
        Me.Button_MainArea_CashDrawer_OpenDrawer.Location = New System.Drawing.Point(14, 38)
        Me.Button_MainArea_CashDrawer_OpenDrawer.Name = "Button_MainArea_CashDrawer_OpenDrawer"
        Me.Button_MainArea_CashDrawer_OpenDrawer.Size = New System.Drawing.Size(145, 30)
        Me.Button_MainArea_CashDrawer_OpenDrawer.TabIndex = 1
        Me.Button_MainArea_CashDrawer_OpenDrawer.Text = "Open Drawer"
        Me.Button_MainArea_CashDrawer_OpenDrawer.UseVisualStyleBackColor = True
        '
        'TabPage_Main_MSR
        '
        Me.TabPage_Main_MSR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage_Main_MSR.Controls.Add(Me.Button_MainArea_MSR_ClearTracks)
        Me.TabPage_Main_MSR.Controls.Add(Me.CheckBox_MainArea_MSR_SendSentinels)
        Me.TabPage_Main_MSR.Controls.Add(Me.Panel7)
        Me.TabPage_Main_MSR.Controls.Add(Me.Panel6)
        Me.TabPage_Main_MSR.Controls.Add(Me.Panel5)
        Me.TabPage_Main_MSR.Controls.Add(Me.Panel4)
        Me.TabPage_Main_MSR.Controls.Add(Me.Button_MainArea_MSR_CheckFeatures)
        Me.TabPage_Main_MSR.Controls.Add(Me.Label_MainTitle_MSR)
        Me.TabPage_Main_MSR.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Main_MSR.Name = "TabPage_Main_MSR"
        Me.TabPage_Main_MSR.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Main_MSR.Size = New System.Drawing.Size(670, 206)
        Me.TabPage_Main_MSR.TabIndex = 1
        Me.TabPage_Main_MSR.Text = "MSR"
        Me.TabPage_Main_MSR.UseVisualStyleBackColor = True
        '
        'Button_MainArea_MSR_ClearTracks
        '
        Me.Button_MainArea_MSR_ClearTracks.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_MainArea_MSR_ClearTracks.Location = New System.Drawing.Point(566, 176)
        Me.Button_MainArea_MSR_ClearTracks.Name = "Button_MainArea_MSR_ClearTracks"
        Me.Button_MainArea_MSR_ClearTracks.Size = New System.Drawing.Size(79, 23)
        Me.Button_MainArea_MSR_ClearTracks.TabIndex = 11
        Me.Button_MainArea_MSR_ClearTracks.Text = "Clear Tracks"
        Me.Button_MainArea_MSR_ClearTracks.UseVisualStyleBackColor = True
        '
        'CheckBox_MainArea_MSR_SendSentinels
        '
        Me.CheckBox_MainArea_MSR_SendSentinels.AutoSize = True
        Me.CheckBox_MainArea_MSR_SendSentinels.Location = New System.Drawing.Point(174, 46)
        Me.CheckBox_MainArea_MSR_SendSentinels.Name = "CheckBox_MainArea_MSR_SendSentinels"
        Me.CheckBox_MainArea_MSR_SendSentinels.Size = New System.Drawing.Size(195, 17)
        Me.CheckBox_MainArea_MSR_SendSentinels.TabIndex = 10
        Me.CheckBox_MainArea_MSR_SendSentinels.Text = "Send Sentinels (Special Characters)"
        Me.CheckBox_MainArea_MSR_SendSentinels.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.TextBox_MainArea_MSR_Track4)
        Me.Panel7.Controls.Add(Me.Label5)
        Me.Panel7.Location = New System.Drawing.Point(14, 148)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(631, 24)
        Me.Panel7.TabIndex = 9
        '
        'TextBox_MainArea_MSR_Track4
        '
        Me.TextBox_MainArea_MSR_Track4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_MainArea_MSR_Track4.Location = New System.Drawing.Point(153, 2)
        Me.TextBox_MainArea_MSR_Track4.Name = "TextBox_MainArea_MSR_Track4"
        Me.TextBox_MainArea_MSR_Track4.ReadOnly = True
        Me.TextBox_MainArea_MSR_Track4.Size = New System.Drawing.Size(475, 20)
        Me.TextBox_MainArea_MSR_Track4.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Track 4"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Label11)
        Me.Panel6.Controls.Add(Me.TextBox_MainArea_MSR_Track3)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Location = New System.Drawing.Point(14, 123)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(631, 24)
        Me.Panel6.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label11.Location = New System.Drawing.Point(55, 5)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "; ? =    107 nums"
        '
        'TextBox_MainArea_MSR_Track3
        '
        Me.TextBox_MainArea_MSR_Track3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_MainArea_MSR_Track3.Location = New System.Drawing.Point(153, 2)
        Me.TextBox_MainArea_MSR_Track3.Name = "TextBox_MainArea_MSR_Track3"
        Me.TextBox_MainArea_MSR_Track3.ReadOnly = True
        Me.TextBox_MainArea_MSR_Track3.Size = New System.Drawing.Size(475, 20)
        Me.TextBox_MainArea_MSR_Track3.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Track 3 "
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label10)
        Me.Panel5.Controls.Add(Me.TextBox_MainArea_MSR_Track2)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Location = New System.Drawing.Point(14, 98)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(631, 24)
        Me.Panel5.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label10.Location = New System.Drawing.Point(54, 5)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(83, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "; ? =     40 nums"
        '
        'TextBox_MainArea_MSR_Track2
        '
        Me.TextBox_MainArea_MSR_Track2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_MainArea_MSR_Track2.Location = New System.Drawing.Point(153, 2)
        Me.TextBox_MainArea_MSR_Track2.Name = "TextBox_MainArea_MSR_Track2"
        Me.TextBox_MainArea_MSR_Track2.ReadOnly = True
        Me.TextBox_MainArea_MSR_Track2.Size = New System.Drawing.Size(475, 20)
        Me.TextBox_MainArea_MSR_Track2.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Track 2"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.TextBox_MainArea_MSR_Track1)
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Location = New System.Drawing.Point(14, 73)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(631, 24)
        Me.Panel4.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label9.Location = New System.Drawing.Point(54, 5)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "% ? ^   79 char"
        '
        'TextBox_MainArea_MSR_Track1
        '
        Me.TextBox_MainArea_MSR_Track1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_MainArea_MSR_Track1.Location = New System.Drawing.Point(153, 2)
        Me.TextBox_MainArea_MSR_Track1.Name = "TextBox_MainArea_MSR_Track1"
        Me.TextBox_MainArea_MSR_Track1.ReadOnly = True
        Me.TextBox_MainArea_MSR_Track1.Size = New System.Drawing.Size(475, 20)
        Me.TextBox_MainArea_MSR_Track1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Track 1"
        '
        'Button_MainArea_MSR_CheckFeatures
        '
        Me.Button_MainArea_MSR_CheckFeatures.Location = New System.Drawing.Point(14, 38)
        Me.Button_MainArea_MSR_CheckFeatures.Name = "Button_MainArea_MSR_CheckFeatures"
        Me.Button_MainArea_MSR_CheckFeatures.Size = New System.Drawing.Size(145, 30)
        Me.Button_MainArea_MSR_CheckFeatures.TabIndex = 5
        Me.Button_MainArea_MSR_CheckFeatures.Text = "Check MSR Features"
        Me.Button_MainArea_MSR_CheckFeatures.UseVisualStyleBackColor = True
        '
        'Label_MainTitle_MSR
        '
        Me.Label_MainTitle_MSR.AutoSize = True
        Me.Label_MainTitle_MSR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MainTitle_MSR.Location = New System.Drawing.Point(11, 11)
        Me.Label_MainTitle_MSR.Name = "Label_MainTitle_MSR"
        Me.Label_MainTitle_MSR.Size = New System.Drawing.Size(34, 13)
        Me.Label_MainTitle_MSR.TabIndex = 4
        Me.Label_MainTitle_MSR.Text = "MSR"
        '
        'TabPage_Main_Dallas
        '
        Me.TabPage_Main_Dallas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TabPage_Main_Dallas.Controls.Add(Me.Label_MainTitle_Dallas)
        Me.TabPage_Main_Dallas.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Main_Dallas.Name = "TabPage_Main_Dallas"
        Me.TabPage_Main_Dallas.Size = New System.Drawing.Size(670, 206)
        Me.TabPage_Main_Dallas.TabIndex = 2
        Me.TabPage_Main_Dallas.Text = "Dallas"
        Me.TabPage_Main_Dallas.UseVisualStyleBackColor = True
        '
        'Label_MainTitle_Dallas
        '
        Me.Label_MainTitle_Dallas.AutoSize = True
        Me.Label_MainTitle_Dallas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MainTitle_Dallas.Location = New System.Drawing.Point(11, 11)
        Me.Label_MainTitle_Dallas.Name = "Label_MainTitle_Dallas"
        Me.Label_MainTitle_Dallas.Size = New System.Drawing.Size(42, 13)
        Me.Label_MainTitle_Dallas.TabIndex = 5
        Me.Label_MainTitle_Dallas.Text = "Dallas"
        '
        'FlowLayoutPanel_Toolbar_TabControlMain
        '
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.AutoScroll = True
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.Button_OPOSToolbar_Open)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.Button_OPOSToolbar_Claim)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.CheckBox_OPOSToolbar_DeviceEnabled)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.Button_OPOSToolbar_Release)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Controls.Add(Me.Button_OPOSToolbar_Close)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Location = New System.Drawing.Point(152, 66)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Name = "FlowLayoutPanel_Toolbar_TabControlMain"
        Me.FlowLayoutPanel_Toolbar_TabControlMain.Size = New System.Drawing.Size(678, 33)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.TabIndex = 4
        '
        'Button_OPOSToolbar_Open
        '
        Me.Button_OPOSToolbar_Open.Location = New System.Drawing.Point(3, 3)
        Me.Button_OPOSToolbar_Open.Name = "Button_OPOSToolbar_Open"
        Me.Button_OPOSToolbar_Open.Size = New System.Drawing.Size(50, 23)
        Me.Button_OPOSToolbar_Open.TabIndex = 0
        Me.Button_OPOSToolbar_Open.Text = "Open"
        Me.Button_OPOSToolbar_Open.UseVisualStyleBackColor = True
        '
        'Button_OPOSToolbar_Claim
        '
        Me.Button_OPOSToolbar_Claim.Location = New System.Drawing.Point(59, 3)
        Me.Button_OPOSToolbar_Claim.Name = "Button_OPOSToolbar_Claim"
        Me.Button_OPOSToolbar_Claim.Size = New System.Drawing.Size(50, 23)
        Me.Button_OPOSToolbar_Claim.TabIndex = 1
        Me.Button_OPOSToolbar_Claim.Text = "Claim"
        Me.Button_OPOSToolbar_Claim.UseVisualStyleBackColor = True
        '
        'CheckBox_OPOSToolbar_DeviceEnabled
        '
        Me.CheckBox_OPOSToolbar_DeviceEnabled.AutoSize = True
        Me.CheckBox_OPOSToolbar_DeviceEnabled.Location = New System.Drawing.Point(115, 3)
        Me.CheckBox_OPOSToolbar_DeviceEnabled.Name = "CheckBox_OPOSToolbar_DeviceEnabled"
        Me.CheckBox_OPOSToolbar_DeviceEnabled.Size = New System.Drawing.Size(99, 17)
        Me.CheckBox_OPOSToolbar_DeviceEnabled.TabIndex = 3
        Me.CheckBox_OPOSToolbar_DeviceEnabled.Text = "DeviceEnabled"
        Me.CheckBox_OPOSToolbar_DeviceEnabled.UseVisualStyleBackColor = True
        '
        'CheckBox_OPOSToolbar_KeepDataEventsEnabled
        '
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.AutoSize = True
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.Location = New System.Drawing.Point(220, 3)
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.Name = "CheckBox_OPOSToolbar_KeepDataEventsEnabled"
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.Size = New System.Drawing.Size(155, 17)
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.TabIndex = 4
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.Text = "Keep Data Events Enabled"
        Me.CheckBox_OPOSToolbar_KeepDataEventsEnabled.UseVisualStyleBackColor = True
        '
        'Button_OPOSToolbar_Release
        '
        Me.Button_OPOSToolbar_Release.Location = New System.Drawing.Point(381, 3)
        Me.Button_OPOSToolbar_Release.Name = "Button_OPOSToolbar_Release"
        Me.Button_OPOSToolbar_Release.Size = New System.Drawing.Size(63, 23)
        Me.Button_OPOSToolbar_Release.TabIndex = 6
        Me.Button_OPOSToolbar_Release.Text = "Release"
        Me.Button_OPOSToolbar_Release.UseVisualStyleBackColor = True
        '
        'Button_OPOSToolbar_Close
        '
        Me.Button_OPOSToolbar_Close.Location = New System.Drawing.Point(450, 3)
        Me.Button_OPOSToolbar_Close.Name = "Button_OPOSToolbar_Close"
        Me.Button_OPOSToolbar_Close.Size = New System.Drawing.Size(61, 23)
        Me.Button_OPOSToolbar_Close.TabIndex = 5
        Me.Button_OPOSToolbar_Close.Text = "Close"
        Me.Button_OPOSToolbar_Close.UseVisualStyleBackColor = True
        '
        'Button_OPOSToolbar_OPOSStatus
        '
        Me.Button_OPOSToolbar_OPOSStatus.Location = New System.Drawing.Point(262, 34)
        Me.Button_OPOSToolbar_OPOSStatus.Name = "Button_OPOSToolbar_OPOSStatus"
        Me.Button_OPOSToolbar_OPOSStatus.Size = New System.Drawing.Size(83, 23)
        Me.Button_OPOSToolbar_OPOSStatus.TabIndex = 7
        Me.Button_OPOSToolbar_OPOSStatus.Text = "OPOS Status"
        Me.Button_OPOSToolbar_OPOSStatus.UseVisualStyleBackColor = True
        '
        'Button_OPOSToolbar_ClearResults
        '
        Me.Button_OPOSToolbar_ClearResults.Location = New System.Drawing.Point(64, 362)
        Me.Button_OPOSToolbar_ClearResults.Name = "Button_OPOSToolbar_ClearResults"
        Me.Button_OPOSToolbar_ClearResults.Size = New System.Drawing.Size(79, 23)
        Me.Button_OPOSToolbar_ClearResults.TabIndex = 7
        Me.Button_OPOSToolbar_ClearResults.Text = "Clear Results"
        Me.Button_OPOSToolbar_ClearResults.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel_OPOSStatusBar
        '
        Me.FlowLayoutPanel_OPOSStatusBar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_OPOSStatusBar.Controls.Add(Me.Label_OPOSStatus_DeviceName)
        Me.FlowLayoutPanel_OPOSStatusBar.Controls.Add(Me.Label_OPOSStatus_OpenState)
        Me.FlowLayoutPanel_OPOSStatusBar.Controls.Add(Me.Label_OPOSStatus_ClaimState)
        Me.FlowLayoutPanel_OPOSStatusBar.Controls.Add(Me.Label_OPOSStatus_EnableState)
        Me.FlowLayoutPanel_OPOSStatusBar.Controls.Add(Me.Label_OPOSStatus_Summary)
        Me.FlowLayoutPanel_OPOSStatusBar.Location = New System.Drawing.Point(7, 555)
        Me.FlowLayoutPanel_OPOSStatusBar.Name = "FlowLayoutPanel_OPOSStatusBar"
        Me.FlowLayoutPanel_OPOSStatusBar.Size = New System.Drawing.Size(421, 20)
        Me.FlowLayoutPanel_OPOSStatusBar.TabIndex = 5
        '
        'Label_OPOSStatus_DeviceName
        '
        Me.Label_OPOSStatus_DeviceName.AutoSize = True
        Me.Label_OPOSStatus_DeviceName.ForeColor = System.Drawing.Color.Red
        Me.Label_OPOSStatus_DeviceName.Location = New System.Drawing.Point(3, 0)
        Me.Label_OPOSStatus_DeviceName.Name = "Label_OPOSStatus_DeviceName"
        Me.Label_OPOSStatus_DeviceName.Size = New System.Drawing.Size(81, 13)
        Me.Label_OPOSStatus_DeviceName.TabIndex = 3
        Me.Label_OPOSStatus_DeviceName.Text = "**NO DEVICE**"
        '
        'Label_OPOSStatus_OpenState
        '
        Me.Label_OPOSStatus_OpenState.AutoSize = True
        Me.Label_OPOSStatus_OpenState.ForeColor = System.Drawing.Color.Red
        Me.Label_OPOSStatus_OpenState.Location = New System.Drawing.Point(90, 0)
        Me.Label_OPOSStatus_OpenState.Name = "Label_OPOSStatus_OpenState"
        Me.Label_OPOSStatus_OpenState.Size = New System.Drawing.Size(39, 13)
        Me.Label_OPOSStatus_OpenState.TabIndex = 0
        Me.Label_OPOSStatus_OpenState.Text = "Closed"
        '
        'Label_OPOSStatus_ClaimState
        '
        Me.Label_OPOSStatus_ClaimState.AutoSize = True
        Me.Label_OPOSStatus_ClaimState.ForeColor = System.Drawing.Color.Red
        Me.Label_OPOSStatus_ClaimState.Location = New System.Drawing.Point(135, 0)
        Me.Label_OPOSStatus_ClaimState.Name = "Label_OPOSStatus_ClaimState"
        Me.Label_OPOSStatus_ClaimState.Size = New System.Drawing.Size(57, 13)
        Me.Label_OPOSStatus_ClaimState.TabIndex = 1
        Me.Label_OPOSStatus_ClaimState.Text = "Unclaimed"
        '
        'Label_OPOSStatus_EnableState
        '
        Me.Label_OPOSStatus_EnableState.AutoSize = True
        Me.Label_OPOSStatus_EnableState.ForeColor = System.Drawing.Color.Red
        Me.Label_OPOSStatus_EnableState.Location = New System.Drawing.Point(198, 0)
        Me.Label_OPOSStatus_EnableState.Name = "Label_OPOSStatus_EnableState"
        Me.Label_OPOSStatus_EnableState.Size = New System.Drawing.Size(48, 13)
        Me.Label_OPOSStatus_EnableState.TabIndex = 2
        Me.Label_OPOSStatus_EnableState.Text = "Disabled"
        '
        'Label_OPOSStatus_Summary
        '
        Me.Label_OPOSStatus_Summary.AutoSize = True
        Me.Label_OPOSStatus_Summary.ForeColor = System.Drawing.Color.Red
        Me.Label_OPOSStatus_Summary.Location = New System.Drawing.Point(252, 0)
        Me.Label_OPOSStatus_Summary.Name = "Label_OPOSStatus_Summary"
        Me.Label_OPOSStatus_Summary.Size = New System.Drawing.Size(10, 13)
        Me.Label_OPOSStatus_Summary.TabIndex = 4
        Me.Label_OPOSStatus_Summary.Text = "-"
        Me.Label_OPOSStatus_Summary.Visible = False
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.TextBox_Results)
        Me.Panel3.Location = New System.Drawing.Point(11, 388)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(815, 161)
        Me.Panel3.TabIndex = 6
        '
        'TextBox_Results
        '
        Me.TextBox_Results.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_Results.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Results.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Results.Multiline = True
        Me.TextBox_Results.Name = "TextBox_Results"
        Me.TextBox_Results.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_Results.Size = New System.Drawing.Size(813, 159)
        Me.TextBox_Results.TabIndex = 0
        '
        'Label_ResultsTitle
        '
        Me.Label_ResultsTitle.AutoSize = True
        Me.Label_ResultsTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_ResultsTitle.Location = New System.Drawing.Point(9, 367)
        Me.Label_ResultsTitle.Name = "Label_ResultsTitle"
        Me.Label_ResultsTitle.Size = New System.Drawing.Size(49, 13)
        Me.Label_ResultsTitle.TabIndex = 7
        Me.Label_ResultsTitle.Text = "Results"
        '
        'ComboBox_Devices
        '
        Me.ComboBox_Devices.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_Devices.FormattingEnabled = True
        Me.ComboBox_Devices.Location = New System.Drawing.Point(283, 102)
        Me.ComboBox_Devices.Name = "ComboBox_Devices"
        Me.ComboBox_Devices.Size = New System.Drawing.Size(543, 21)
        Me.ComboBox_Devices.TabIndex = 8
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel1.Controls.Add(Me.Label_WebSocketServer_Status)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(602, 555)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(223, 19)
        Me.FlowLayoutPanel1.TabIndex = 9
        '
        'Label_WebSocketServer_Status
        '
        Me.Label_WebSocketServer_Status.AutoSize = True
        Me.Label_WebSocketServer_Status.ForeColor = System.Drawing.Color.Red
        Me.Label_WebSocketServer_Status.Location = New System.Drawing.Point(139, 0)
        Me.Label_WebSocketServer_Status.Name = "Label_WebSocketServer_Status"
        Me.Label_WebSocketServer_Status.Size = New System.Drawing.Size(81, 13)
        Me.Label_WebSocketServer_Status.TabIndex = 3
        Me.Label_WebSocketServer_Status.Text = "Server Stopped"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(152, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "OPOS Commands"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(152, 106)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(125, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Select OPOS Device"
        '
        'NotifyIcon_SystemTray_MainApp
        '
        Me.NotifyIcon_SystemTray_MainApp.ContextMenuStrip = Me.ContextMenuStrip_SystemTray_MainApp
        Me.NotifyIcon_SystemTray_MainApp.Icon = CType(resources.GetObject("NotifyIcon_SystemTray_MainApp.Icon"), System.Drawing.Icon)
        Me.NotifyIcon_SystemTray_MainApp.Text = "EPOS Core"
        Me.NotifyIcon_SystemTray_MainApp.Visible = True
        '
        'ContextMenuStrip_SystemTray_MainApp
        '
        Me.ContextMenuStrip_SystemTray_MainApp.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ContextMenuStrip_SystemTray_MainApp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowApplicationToolStripMenuItem, Me.HideApplicationToolStripMenuItem, Me.AppSettingsToolStripMenuItem1, Me.ToolStripSeparator7, Me.ResetToolStripMenuItem, Me.ToolStripSeparator5, Me.AboutToolStripMenuItem1, Me.ToolStripSeparator6, Me.ExitToolStripMenuItem1})
        Me.ContextMenuStrip_SystemTray_MainApp.Name = "ContextMenuStrip_SystemTray_MainApp"
        Me.ContextMenuStrip_SystemTray_MainApp.Size = New System.Drawing.Size(168, 154)
        '
        'ShowApplicationToolStripMenuItem
        '
        Me.ShowApplicationToolStripMenuItem.Name = "ShowApplicationToolStripMenuItem"
        Me.ShowApplicationToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ShowApplicationToolStripMenuItem.Text = "Show Application"
        '
        'HideApplicationToolStripMenuItem
        '
        Me.HideApplicationToolStripMenuItem.Name = "HideApplicationToolStripMenuItem"
        Me.HideApplicationToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.HideApplicationToolStripMenuItem.Text = "Hide Application"
        '
        'AppSettingsToolStripMenuItem1
        '
        Me.AppSettingsToolStripMenuItem1.Name = "AppSettingsToolStripMenuItem1"
        Me.AppSettingsToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.AppSettingsToolStripMenuItem1.Text = "App Settings"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(164, 6)
        '
        'ResetToolStripMenuItem
        '
        Me.ResetToolStripMenuItem.Name = "ResetToolStripMenuItem"
        Me.ResetToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ResetToolStripMenuItem.Text = "Reset"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(164, 6)
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.AboutToolStripMenuItem1.Text = "About"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(164, 6)
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'Button_OPOSToolbar_CloseAll
        '
        Me.Button_OPOSToolbar_CloseAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_OPOSToolbar_CloseAll.Location = New System.Drawing.Point(711, 36)
        Me.Button_OPOSToolbar_CloseAll.Name = "Button_OPOSToolbar_CloseAll"
        Me.Button_OPOSToolbar_CloseAll.Size = New System.Drawing.Size(114, 23)
        Me.Button_OPOSToolbar_CloseAll.TabIndex = 12
        Me.Button_OPOSToolbar_CloseAll.Text = "Close All Devices"
        Me.Button_OPOSToolbar_CloseAll.UseVisualStyleBackColor = True
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(177, 6)
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(834, 578)
        Me.Controls.Add(Me.Button_OPOSToolbar_CloseAll)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.ComboBox_Devices)
        Me.Controls.Add(Me.Label_ResultsTitle)
        Me.Controls.Add(Me.Button_OPOSToolbar_OPOSStatus)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.FlowLayoutPanel_OPOSStatusBar)
        Me.Controls.Add(Me.FlowLayoutPanel_Toolbar_TabControlMain)
        Me.Controls.Add(Me.TabControl_Main)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel_DeviceList_Wrap)
        Me.Controls.Add(Me.Button_OPOSToolbar_ClearResults)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip_Main
        Me.MinimumSize = New System.Drawing.Size(600, 400)
        Me.Name = "FormMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EPOS Core"
        Me.FlowLayoutPanel_DeviceList.ResumeLayout(False)
        Me.Panel_DeviceList_Wrap.ResumeLayout(False)
        Me.Panel_DeviceList_Wrap.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.MenuStrip_Main.ResumeLayout(False)
        Me.MenuStrip_Main.PerformLayout()
        Me.TabControl_Main.ResumeLayout(False)
        Me.TabPage_Main_CashDrawer.ResumeLayout(False)
        Me.TabPage_Main_CashDrawer.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage_Main_MSR.ResumeLayout(False)
        Me.TabPage_Main_MSR.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.TabPage_Main_Dallas.ResumeLayout(False)
        Me.TabPage_Main_Dallas.PerformLayout()
        Me.FlowLayoutPanel_Toolbar_TabControlMain.ResumeLayout(False)
        Me.FlowLayoutPanel_Toolbar_TabControlMain.PerformLayout()
        Me.FlowLayoutPanel_OPOSStatusBar.ResumeLayout(False)
        Me.FlowLayoutPanel_OPOSStatusBar.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.ContextMenuStrip_SystemTray_MainApp.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FlowLayoutPanel_DeviceList As FlowLayoutPanel
    Friend WithEvents Button_DeviceList_CashDrawer As Button
    Friend WithEvents Panel_DeviceList_Wrap As Panel
    Friend WithEvents Label_DeviceList_Title As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents MenuStrip_Main As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button_DeviceList_MSR As Button
    Friend WithEvents Button_DeviceList_Dallas As Button
    Friend WithEvents TabControl_Main As TabControl
    Friend WithEvents TabPage_Main_CashDrawer As TabPage
    Friend WithEvents TabPage_Main_MSR As TabPage
    Friend WithEvents TabPage_Main_Dallas As TabPage
    Friend WithEvents FlowLayoutPanel_Toolbar_TabControlMain As FlowLayoutPanel
    Friend WithEvents Button_OPOSToolbar_Open As Button
    Friend WithEvents Button_OPOSToolbar_Claim As Button
    Friend WithEvents CheckBox_OPOSToolbar_DeviceEnabled As CheckBox
    Friend WithEvents CheckBox_OPOSToolbar_KeepDataEventsEnabled As CheckBox
    Friend WithEvents Button_OPOSToolbar_Close As Button
    Friend WithEvents Button_OPOSToolbar_Release As Button
    Friend WithEvents Button_OPOSToolbar_ClearResults As Button
    Friend WithEvents Button_MainArea_CashDrawer_GetDrawerState As Button
    Friend WithEvents Button_MainArea_CashDrawer_OpenDrawer As Button
    Friend WithEvents FlowLayoutPanel_OPOSStatusBar As FlowLayoutPanel
    Friend WithEvents Label_OPOSStatus_OpenState As Label
    Friend WithEvents Label_OPOSStatus_ClaimState As Label
    Friend WithEvents Label_OPOSStatus_EnableState As Label
    Friend WithEvents Label_MainTitle_CashDrawer As Label
    Friend WithEvents Label_MainTitle_MSR As Label
    Friend WithEvents Label_MainTitle_Dallas As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox_MainArea_CashDrawer_DrawerState As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBox_Results As TextBox
    Friend WithEvents Label_ResultsTitle As Label
    Friend WithEvents ComboBox_Devices As ComboBox
    Friend WithEvents Label_OPOSStatus_DeviceName As Label
    Friend WithEvents Button_MainArea_MSR_CheckFeatures As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox_MainArea_MSR_Track1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents TextBox_MainArea_MSR_Track4 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TextBox_MainArea_MSR_Track3 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBox_MainArea_MSR_Track2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CheckBox_MainArea_MSR_SendSentinels As CheckBox
    Friend WithEvents Button_MainArea_MSR_ClearTracks As Button
    Friend WithEvents Button_WebSocketServer_Stop As Button
    Friend WithEvents Button_WebSocketServer_Start As Button
    Friend WithEvents Panel8 As Panel
    Friend WithEvents TextBox_WebSocketServer_Port As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Label_WebSocketServer_Status As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents OpenApplicationFolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ViewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConfigFileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents AppSettingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotifyIcon_SystemTray_MainApp As NotifyIcon
    Friend WithEvents ContextMenuStrip_SystemTray_MainApp As ContextMenuStrip
    Friend WithEvents ShowApplicationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AppSettingsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents HideApplicationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HideApplicationToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Button_WebSocketServer_Test As Button
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetUIFieldsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button_OPOSToolbar_OPOSStatus As Button
    Friend WithEvents Label_OPOSStatus_Summary As Label
    Friend WithEvents LogsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FolderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents Button_OPOSToolbar_CloseAll As Button
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
End Class
