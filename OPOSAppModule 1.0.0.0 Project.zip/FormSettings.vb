﻿


Imports System.IO

Public Class FormSettings

    Private _settings As AppSettings ' No "New" here!
    Private changesDetected As Boolean = False

    ' Create a custom constructor
    Public Sub New(settingsToUse As AppSettings)
        InitializeComponent() ' Required for WinForms
        _settings = settingsToUse
    End Sub


    Private Sub FormSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ApplySettingsToUI()
        changesDetected = False
    End Sub


    Private Sub FormSettings_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        VB.Log("EVENT: FormSettings SHOWN", LogLevel.Debug)
    End Sub


    Private Sub LoadConfigFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadConfigFileToolStripMenuItem.Click
        Try
            ' Create OpenFileDialog
            Using ofd As New OpenFileDialog()
                ' Default to application root directory
                ofd.InitialDirectory = Application.StartupPath

                ' Filter for JSON files but allow all files
                ofd.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*"
                ofd.FilterIndex = 1 ' Default to JSON

                ' Show dialog and check if user clicked OK
                If ofd.ShowDialog() = DialogResult.OK Then
                    Dim selectedFile As String = ofd.FileName

                    ' Make sure the file exists before calling load function
                    If System.IO.File.Exists(selectedFile) Then
                        _settings.LoadSettings_FromFile(selectedFile)
                        ApplySettingsToUI()
                        changesDetected = False
                        'MessageBox.Show("Settings loaded from: " & selectedFile, "Load Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("The selected file does not exist.", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error opening file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub





    Private Sub Button_Settings_App_Defaults_Click(sender As Object, e As EventArgs) Handles Button_Settings_App_Defaults.Click
        VB.Log("DIALOG SHOW: CONFIRM: Are you sure you want to reset all settings to factory defaults?", LogLevel.Debug)
        Dim result As DialogResult = MessageBox.Show(
        "CONFIRM:" & vbCrLf & "Are you sure you want to reset all settings to factory defaults?",
        "Confirm Reset",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Warning)

        If result = DialogResult.Yes Then
            VB.Log("DIALOG SHOW: ANSWER: Yes", LogLevel.Debug)

            ' 1. Reset the underlying object
            _settings.ResetSettingsToDefaults()

            ' 2. Refresh the UI to reflect the reset values
            ApplySettingsToUI()

            ' 3. Mark as changed so the user has to Save to write to disk
            changesDetected = True

            VB.Log("Settings reset to defaults.", LogLevel.Info)
        Else
            VB.Log("DIALOG SHOW: ANSWER: No", LogLevel.Debug)
        End If
    End Sub



    Private Sub CheckBox_Settings_App_LaunchSilently_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_Settings_App_LaunchSilently.CheckedChanged
        changesDetected = True
    End Sub



    Private Sub TextBox_Settings_App_LogFileName_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Settings_App_LogFileName.TextChanged
        changesDetected = True
    End Sub

    Private Sub TextBox_Settings_App_LogFolder_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Settings_App_LogFolder.TextChanged
        changesDetected = True
    End Sub

    Private Sub ComboBox_Settings_App_LogLevel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_Settings_App_LogLevel.SelectedIndexChanged
        changesDetected = True
    End Sub

    Private Sub RadioButton_Settings_App_TextFormat_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_Settings_App_TextFormat.CheckedChanged
        changesDetected = True
    End Sub

    Private Sub RadioButton_Settings_App_NDJSONFormat_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_Settings_App_NDJSONFormat.CheckedChanged
        changesDetected = True
    End Sub

    Private Sub NumericUpDown_Settings_App_RetentionDays_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown_Settings_App_RetentionDays.ValueChanged
        changesDetected = True
    End Sub



    Private Sub CheckBox_Settings_WebSocketServer_StartOnLaunch_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_Settings_WebSocketServer_StartOnLaunch.CheckedChanged
        changesDetected = True
    End Sub

    Private Sub TextBox_Settings_WebSocketServer_Port_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Settings_WebSocketServer_Port.TextChanged
        changesDetected = True
    End Sub






    Private Sub Button_Settings_Save_Click(sender As Object, e As EventArgs) Handles Button_Settings_Save.Click
        SaveChanges()
    End Sub



    ' V! before extra logging UI controls 
    'Private Sub ApplySettingsToUI()
    '    ' 1. Port Number
    '    TextBox_Settings_WebSocketServer_Port.Text = _settings.WebSocketPort.ToString()
    '    CheckBox_Settings_App_LaunchSilently.Checked = _settings.StartSilent
    '    CheckBox_Settings_WebSocketServer_StartOnLaunch.Checked = _settings.StartWebSocketOnLaunch
    'End Sub



    ' V2
    Private Sub ApplySettingsToUI()
        ' Existing WebSocket mappings
        TextBox_Settings_WebSocketServer_Port.Text = _settings.WebSocketPort.ToString()
        CheckBox_Settings_App_LaunchSilently.Checked = _settings.StartSilent
        CheckBox_Settings_WebSocketServer_StartOnLaunch.Checked = _settings.StartWebSocketOnLaunch

        ' --- NEW: Logging Mappings ---
        TextBox_Settings_App_LogFileName.Text = _settings.LogFileName
        TextBox_Settings_App_LogFolder.Text = _settings.LogPath
        NumericUpDown_Settings_App_RetentionDays.Value = _settings.RetentionDays

        ' Set the LogLevel ComboBox
        ComboBox_Settings_App_LogLevel.DataSource = [Enum].GetValues(GetType(LogLevel))
        ComboBox_Settings_App_LogLevel.SelectedItem = _settings.MinimumLevel

        ' Set Format RadioButtons
        If _settings.LogFormat.ToLower() = "ndjson" Then
            RadioButton_Settings_App_NDJSONFormat.Checked = True
        Else
            RadioButton_Settings_App_TextFormat.Checked = True
        End If
    End Sub



    '' V1 before extra logging UI controls 
    'Private Sub CaptureSettingsFromUI()
    '    Dim portNum As Integer
    '    If Integer.TryParse(TextBox_Settings_WebSocketServer_Port.Text, portNum) Then
    '        _settings.WebSocketPort = portNum
    '    End If
    '    _settings.StartSilent = CheckBox_Settings_App_LaunchSilently.Checked
    '    _settings.StartWebSocketOnLaunch = CheckBox_Settings_WebSocketServer_StartOnLaunch.Checked
    'End Sub



    ' V2
    Private Sub CaptureSettingsFromUI()
        ' Existing WebSocket captures
        Dim portNum As Integer
        If Integer.TryParse(TextBox_Settings_WebSocketServer_Port.Text, portNum) Then
            _settings.WebSocketPort = portNum
        End If
        _settings.StartSilent = CheckBox_Settings_App_LaunchSilently.Checked
        _settings.StartWebSocketOnLaunch = CheckBox_Settings_WebSocketServer_StartOnLaunch.Checked

        ' --- NEW: Logging Captures ---
        _settings.LogFileName = TextBox_Settings_App_LogFileName.Text
        _settings.LogPath = TextBox_Settings_App_LogFolder.Text
        _settings.RetentionDays = CInt(NumericUpDown_Settings_App_RetentionDays.Value)
        _settings.MinimumLevel = CType(ComboBox_Settings_App_LogLevel.SelectedItem, LogLevel)
        _settings.LogFormat = If(RadioButton_Settings_App_NDJSONFormat.Checked, "NDJSON", "text")
    End Sub




    ' V1  before extra logging UI controls 
    'Private Sub SaveChanges()
    '    Try
    '        ' 1. Validate Input - Use TryParse instead of CInt to prevent crashes
    '        Dim portNumber As Integer
    '        If Not Integer.TryParse(TextBox_Settings_WebSocketServer_Port.Text, portNumber) Then
    '            MessageBox.Show("Please enter a valid numeric port number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '            TextBox_Settings_WebSocketServer_Port.Focus()
    '            Return
    '        End If

    '        ' 2. Range Checking - Ensure the port is valid for TCP/IP
    '        If portNumber < 1 OrElse portNumber > 65535 Then
    '            MessageBox.Show("Port must be between 1 and 65535.", "Range Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '            Return
    '        End If

    '        ' 3. Apply to Object
    '        CaptureSettingsFromUI()

    '        ' 4. Attempt to Save
    '        ' Note: SaveSettings_ToFile already has its own Try/Catch, but we catch 
    '        ' any bubbled-up errors here to decide if we should close the form.
    '        _settings.SaveSettings_ToFile()

    '        ' 5. Success - Provide feedback or just close
    '        ' We only close if the save was successful.
    '        changesDetected = False
    '        Me.DialogResult = DialogResult.OK
    '        Me.Close()

    '    Catch ex As Exception
    '        ' This catches any unexpected errors (e.g., Threading or UI issues)
    '        MessageBox.Show($"An unexpected error occurred while saving: {ex.Message}",
    '                    "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End Try
    'End Sub



    ' V2
    Private Sub SaveChanges()
        Try
            ' 1. Validate Input - Use TryParse instead of CInt to prevent crashes
            Dim portNumber As Integer
            If Not Integer.TryParse(TextBox_Settings_WebSocketServer_Port.Text, portNumber) Then
                MessageBox.Show("Please enter a valid numeric port number.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                TextBox_Settings_WebSocketServer_Port.Focus()
                Return
            End If

            ' 2. Range Checking - Ensure the port is valid for TCP/IP
            If portNumber < 1 OrElse portNumber > 65535 Then
                MessageBox.Show("Port must be between 1 and 65535.", "Range Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' 3. Apply to Object
            CaptureSettingsFromUI()

            ' 4. Attempt to Save
            _settings.SaveSettings_ToFile()

            ' --- NEW: Push changes to the LIVE Logger immediately ---
            VB.LogFileName = _settings.LogFileName
            VB.OutputDirectory = If(String.IsNullOrEmpty(_settings.LogPath),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs"),
                        _settings.LogPath)
            VB.MinimumLevel = _settings.MinimumLevel
            VB.RetentionDays = _settings.RetentionDays
            VB.Format = If(_settings.LogFormat.ToLower() = "ndjson", LogFormat.NDJSON, LogFormat.PlainText)

            'VB.Log("Settings updated and applied to live logger.", LogLevel.Info)

            ' 5. Success - Provide feedback or just close
            ' We only close if the save was successful.
            changesDetected = False
            Me.DialogResult = DialogResult.OK
            Me.Close()

        Catch ex As Exception
            VB.Log($"An unexpected error occurred while saving: ", LogLevel.Trace, ex)
            MessageBox.Show($"An unexpected error occurred while saving: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub




    Private Sub Button_Settings_App_ClearLogs_Click(sender As Object, e As EventArgs) Handles Button_Settings_App_ClearLogs.Click
        ClearApplicationLogFiles()
    End Sub


    Public Shared Sub ClearApplicationLogFiles()
        ' 1. Confirm with the user
        Dim result As DialogResult = MessageBox.Show(
            "Are you sure you want to delete all log files? This cannot be undone.",
            "Confirm Deletion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning)

        If result = DialogResult.No Then Return

        Try
            Dim logDir As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs")

            If Directory.Exists(logDir) Then
                ' 2. Get all files in the directory
                Dim files = Directory.GetFiles(logDir, "*.log")
                Dim deletedCount As Integer = 0
                Dim lockedCount As Integer = 0

                For Each f In files
                    Try
                        File.Delete(f)
                        deletedCount += 1
                    Catch ex As IOException
                        ' This happens if the file is open in another program
                        lockedCount += 1
                    End Try
                Next

                ' 3. Provide Feedback
                If lockedCount > 0 Then
                    MessageBox.Show($"Deleted {deletedCount} logs. {lockedCount} files were in use and could not be deleted.",
                                    "Cleanup Partial", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show($"Successfully cleared {deletedCount} log files.",
                                    "Cleanup Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If

                VB.Log($"User manually cleared log directory. Files deleted: {deletedCount}", LogLevel.Info)
            Else
                MessageBox.Show("Log directory does not exist yet.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show("An error occurred while clearing logs: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub FormSettings_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If changesDetected = True Then
            Dim result As DialogResult = MessageBox.Show(
                "Do you want to save changes before closing?",
                "Save Changes",
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question
            )

            Select Case result
                Case DialogResult.Yes
                    ' Call your save method here
                    SaveChanges()

                Case DialogResult.No
                ' Do nothing, allow form to close

                Case DialogResult.Cancel
                    ' Stop the form from closing
                    e.Cancel = True
            End Select
        End If
    End Sub




End Class